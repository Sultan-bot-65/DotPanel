# DotPanel development checklist

Legend: [x] implemented and statically reviewed · [ ] needs a device/SDK to verify

## Phases
- [x] 1. Project foundation (Gradle, version catalog, Hilt, Room, DataStore, manifest)
- [x] 2. Nothing OS design system (theme, dot-matrix type, components, dark/light)
- [x] 3. Dashboard engine (cards, reorder, hide, sizes, presets)
- [x] 4. Countdown & events (categories, recurrence, reminders, days remaining)
- [x] 5. Quick notes (auto-save, pin, search, colour labels, previews)
- [x] 6. Daily goals (completion %, streaks, history)
- [x] 7. Home screen widgets (5 Glance widgets, config activity, refresh)
- [x] 8. Backup & personalization (JSON export/import with validation, theme, 24h clock, reminder times)
- [x] 9. Unit tests (backup codec, goal stats, events, formatters, widget selection, goals VM)
- [x] 10. Release prep (README, signing config, R8 + shrink, LICENSE, CI workflow)

## Verification still required on a machine with the Android SDK
- [ ] `./gradlew assembleDebug` compiles cleanly
- [ ] `./gradlew testDebugUnitTest` passes
- [ ] Commit generated `app/schemas/*.json`
- [ ] Manual pass: add widgets of each type, deny/allow notification permission, export then import a backup
- [ ] Release build: confirm R8 does not strip serialization/Room/Hilt classes
