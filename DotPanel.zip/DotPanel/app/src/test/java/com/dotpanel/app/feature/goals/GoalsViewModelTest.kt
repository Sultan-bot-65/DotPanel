package com.dotpanel.app.feature.goals

import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.model.GoalCompletion
import com.dotpanel.app.domain.repository.GoalRepository
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import java.time.LocalDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class GoalsViewModelTest {

    private val dispatcher = UnconfinedTestDispatcher()
    private val today = LocalDate.of(2026, 3, 15)
    private val epoch = today.toEpochDay()

    private val goals = mockk<GoalRepository>(relaxed = true)
    private val dates = mockk<DateProvider>()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        every { dates.today() } returns today
        every { dates.todayFlow } returns flowOf(today)
        every { goals.observeGoals() } returns flowOf(
            listOf(Goal(1, "Read", epoch - 1), Goal(2, "Run", epoch - 1)),
        )
        every { goals.observeCompletions() } returns flowOf(listOf(GoalCompletion(1, epoch)))
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `ui state marks today's completed goals and computes progress`() = runTest(dispatcher) {
        val vm = GoalsViewModel(goals, dates)
        backgroundScope.launch(dispatcher) { vm.uiState.collect { } }

        val state = vm.uiState.value
        assertFalse(state.loading)
        assertEquals(listOf(true, false), state.items.map { it.done })
        assertEquals(50, state.stats?.percentToday)
        assertEquals(today, state.today)
    }

    @Test
    fun `toggling an open goal records a completion for today`() = runTest(dispatcher) {
        val vm = GoalsViewModel(goals, dates)
        vm.toggle(GoalItem(Goal(2, "Run", epoch - 1), done = false))
        coVerify(exactly = 1) { goals.setCompleted(2, epoch, true) }
    }

    @Test
    fun `toggling a finished goal clears today's completion`() = runTest(dispatcher) {
        val vm = GoalsViewModel(goals, dates)
        vm.toggle(GoalItem(Goal(1, "Read", epoch - 1), done = true))
        coVerify(exactly = 1) { goals.setCompleted(1, epoch, false) }
    }

    @Test
    fun `blank goal titles are ignored and real ones are trimmed`() = runTest(dispatcher) {
        val vm = GoalsViewModel(goals, dates)
        vm.addGoal("   ")
        vm.addGoal("  Stretch  ")
        coVerify(exactly = 0) { goals.addGoal("   ") }
        coVerify(exactly = 1) { goals.addGoal("Stretch") }
    }

    @Test
    fun `removing a goal archives it through the repository`() = runTest(dispatcher) {
        val vm = GoalsViewModel(goals, dates)
        vm.remove(2)
        coVerify(exactly = 1) { goals.removeGoal(2) }
    }
}
