package com.dotpanel.app.core.util

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class FormattersTest {

    @Test
    fun `days label reads naturally`() {
        assertEquals("Today", daysLabel(0))
        assertEquals("Tomorrow", daysLabel(1))
        assertEquals("Yesterday", daysLabel(-1))
        assertEquals("12 days", daysLabel(12))
        assertEquals("3 days ago", daysLabel(-3))
    }

    @Test
    fun `short days label for dot matrix displays`() {
        assertEquals("NOW", daysShort(0))
        assertEquals("12D", daysShort(12))
        assertEquals("2D AGO", daysShort(-2))
    }

    @Test
    fun `hours are clamped and formatted in 24 hour time`() {
        assertEquals("09:00", formatHour(9, use24Hour = true))
        assertEquals("23:00", formatHour(99, use24Hour = true))
        assertEquals("00:00", formatHour(-4, use24Hour = true))
    }

    @Test
    fun `dates format without locale surprises in their numeric parts`() {
        val formatted = LocalDate.of(2026, 3, 5).formatShort()
        assertEquals(true, formatted.startsWith("5 ") && formatted.endsWith(" 2026"))
    }
}
