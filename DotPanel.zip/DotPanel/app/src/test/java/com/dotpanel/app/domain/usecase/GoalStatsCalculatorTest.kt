package com.dotpanel.app.domain.usecase

import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.model.GoalCompletion
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalStatsCalculatorTest {

    private val today = LocalDate.of(2026, 3, 15)
    private val e = today.toEpochDay()

    private fun done(goalId: Long, vararg offsets: Long) = offsets.map { GoalCompletion(goalId, e + it) }

    @Test
    fun `no goals gives empty stats and a full history window`() {
        val stats = GoalStatsCalculator.calculate(emptyList(), emptyList(), today)
        assertEquals(0, stats.total)
        assertEquals(0, stats.percentToday)
        assertEquals(0, stats.currentStreak)
        assertEquals(14, stats.history.size)
        assertEquals(today, stats.history.last().date)
    }

    @Test
    fun `consecutive days including today form the streak`() {
        val goals = listOf(Goal(1, "Read", e - 3))
        val stats = GoalStatsCalculator.calculate(goals, done(1, -2, -1, 0), today)
        assertEquals(3, stats.currentStreak)
        assertEquals(3, stats.bestStreak)
        assertEquals(100, stats.percentToday)
    }

    @Test
    fun `an unfinished today does not break the streak yet`() {
        val goals = listOf(Goal(1, "Read", e - 3))
        val stats = GoalStatsCalculator.calculate(goals, done(1, -2, -1), today)
        assertEquals(2, stats.currentStreak)
        assertEquals(0, stats.completedToday)
        assertEquals(0, stats.percentToday)
    }

    @Test
    fun `a missed day resets the current streak but keeps the best`() {
        val goals = listOf(Goal(1, "Read", e - 5))
        val stats = GoalStatsCalculator.calculate(goals, done(1, -4, -3, -1, 0), today)
        assertEquals(2, stats.currentStreak)
        assertEquals(2, stats.bestStreak)
        val missed = stats.history.first { it.date == today.minusDays(2) }
        assertEquals(0, missed.completed)
        assertEquals(1, missed.total)
    }

    @Test
    fun `a goal added today does not retroactively break earlier days`() {
        val goals = listOf(Goal(1, "Read", e - 2), Goal(2, "Run", e))
        val stats = GoalStatsCalculator.calculate(goals, done(1, -2, -1, 0), today)
        assertEquals(2, stats.total)
        assertEquals(1, stats.completedToday)
        assertEquals(50, stats.percentToday)
        // Yesterday and the day before were complete (only goal 1 existed); today is not (goal 2).
        assertEquals(2, stats.currentStreak)
    }

    @Test
    fun `history keeps per day progress for old completions`() {
        val goals = listOf(Goal(1, "Read", e - 10), Goal(2, "Run", e - 10))
        val stats = GoalStatsCalculator.calculate(goals, done(1, -5) + done(2, -5, -4), today)
        val fiveAgo = stats.history.first { it.date == today.minusDays(5) }
        assertEquals(2, fiveAgo.completed)
        assertEquals(2, fiveAgo.total)
        val fourAgo = stats.history.first { it.date == today.minusDays(4) }
        assertEquals(1, fourAgo.completed)
        assertTrue(fourAgo.fraction in 0.49f..0.51f)
    }
}
