package com.dotpanel.app.widgets

import androidx.compose.ui.unit.dp
import com.dotpanel.app.domain.model.Event
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.Recurrence
import com.dotpanel.app.domain.model.WidgetConfig
import com.dotpanel.app.domain.model.WidgetType
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WidgetSelectionTest {

    private val today = LocalDate.of(2026, 3, 15)

    private fun upcoming(id: Long, date: LocalDate, recurrence: Recurrence = Recurrence.NONE) =
        Event(id = id, title = "E$id", date = date, recurrence = recurrence).toUpcoming(today)

    private fun config(type: WidgetType, target: Long = WidgetConfig.NO_TARGET) =
        WidgetConfig(appWidgetId = 1, type = type, targetId = target)

    @Test
    fun `countdown picks the nearest event that has not passed`() {
        val all = listOf(
            upcoming(1, today.minusDays(3)),
            upcoming(2, today.plusDays(10)),
            upcoming(3, today.plusDays(2)),
        )
        assertEquals(3L, CountdownSelection.choose(all, null)?.event?.id)
        assertEquals(3L, CountdownSelection.choose(all, config(WidgetType.COUNTDOWN))?.event?.id)
    }

    @Test
    fun `countdown honours the chosen event even after it has passed`() {
        val all = listOf(upcoming(1, today.minusDays(3)), upcoming(2, today.plusDays(1)))
        val chosen = CountdownSelection.choose(all, config(WidgetType.COUNTDOWN, target = 1))
        assertEquals(1L, chosen?.event?.id)
        assertTrue(chosen!!.passed)
    }

    @Test
    fun `countdown falls back to automatic when the chosen event was deleted`() {
        val all = listOf(upcoming(2, today.plusDays(4)))
        assertEquals(2L, CountdownSelection.choose(all, config(WidgetType.COUNTDOWN, target = 99))?.event?.id)
    }

    @Test
    fun `countdown shows nothing when every event has passed`() {
        assertNull(CountdownSelection.choose(listOf(upcoming(1, today.minusDays(1))), null))
        assertNull(CountdownSelection.choose(emptyList(), null))
    }

    @Test
    fun `recurring events count as upcoming`() {
        val birthday = upcoming(1, LocalDate.of(2000, 3, 20), Recurrence.YEARLY)
        assertEquals(5L, birthday.daysRemaining)
        assertEquals(1L, CountdownSelection.choose(listOf(birthday), null)?.event?.id)
    }

    private fun note(id: Long, pinned: Boolean = false, updatedAt: Long = 0, title: String = "N$id", content: String = "") =
        Note(id = id, title = title, content = content, pinned = pinned, updatedAt = updatedAt)

    @Test
    fun `notes widget prefers pinned notes then the most recent`() {
        val all = listOf(note(1, updatedAt = 300), note(2, pinned = true, updatedAt = 100), note(3, pinned = true, updatedAt = 200))
        assertEquals(3L, NoteSelection.choose(all, null)?.id)
        assertEquals(1L, NoteSelection.choose(all.filter { !it.pinned }, null)?.id)
    }

    @Test
    fun `notes widget honours a chosen note and ignores blank ones`() {
        val all = listOf(note(1, updatedAt = 5), note(2, updatedAt = 900, title = "", content = ""))
        assertEquals(1L, NoteSelection.choose(all, null)?.id)
        assertEquals(2L, NoteSelection.choose(all, config(WidgetType.NOTES, target = 2))?.id)
        assertNull(NoteSelection.choose(emptyList(), null))
    }

    @Test
    fun `dot size never exceeds the maximum and always fits the width`() {
        val roomy = DotBitmap.fitDot("12", 500.dp, 500.dp, 8.dp)
        assertEquals(8f, roomy, 0.001f)

        val width = 60.dp
        val text = "365"
        val dot = DotBitmap.fitDot(text, width, 500.dp, 8.dp)
        val columns = text.length * 6 - 1
        val pitch = dot / 0.72f
        assertTrue("text must fit in $width but needs ${pitch * columns}", pitch * columns <= width.value + 0.01f)
    }
}
