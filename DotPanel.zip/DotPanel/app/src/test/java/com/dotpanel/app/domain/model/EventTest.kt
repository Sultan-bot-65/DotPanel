package com.dotpanel.app.domain.model

import java.time.LocalDate
import java.time.LocalDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EventTest {

    private fun event(
        date: LocalDate,
        recurrence: Recurrence = Recurrence.NONE,
        offsets: Set<Int> = emptySet(),
    ) = Event(id = 1, title = "Test", date = date, recurrence = recurrence, reminderOffsets = offsets)

    @Test
    fun `one-off events report days remaining and become passed afterwards`() {
        val e = event(LocalDate.of(2026, 3, 20))
        assertEquals(5L, e.daysRemaining(LocalDate.of(2026, 3, 15)))
        assertEquals(0L, e.daysRemaining(LocalDate.of(2026, 3, 20)))
        val after = e.toUpcoming(LocalDate.of(2026, 3, 22))
        assertEquals(-2L, after.daysRemaining)
        assertTrue(after.passed)
        assertFalse(e.toUpcoming(LocalDate.of(2026, 3, 20)).passed)
    }

    @Test
    fun `yearly events roll to the next anniversary`() {
        val e = event(LocalDate.of(2020, 3, 10), Recurrence.YEARLY)
        assertEquals(LocalDate.of(2027, 3, 10), e.occurrenceOnOrAfter(LocalDate.of(2026, 3, 15)))
        assertEquals(LocalDate.of(2026, 3, 10), e.occurrenceOnOrAfter(LocalDate.of(2026, 3, 1)))
        assertEquals(0L, e.daysRemaining(LocalDate.of(2026, 3, 10)))
    }

    @Test
    fun `a leap day birthday falls back to Feb 28 in common years`() {
        val e = event(LocalDate.of(2024, 2, 29), Recurrence.YEARLY)
        assertEquals(LocalDate.of(2026, 2, 28), e.occurrenceOnOrAfter(LocalDate.of(2026, 1, 1)))
        assertEquals(LocalDate.of(2028, 2, 29), e.occurrenceOnOrAfter(LocalDate.of(2027, 3, 1)))
    }

    @Test
    fun `monthly events clamp to the end of short months`() {
        val e = event(LocalDate.of(2026, 1, 31), Recurrence.MONTHLY)
        assertEquals(LocalDate.of(2026, 2, 28), e.occurrenceOnOrAfter(LocalDate.of(2026, 2, 10)))
        assertEquals(LocalDate.of(2026, 3, 31), e.occurrenceOnOrAfter(LocalDate.of(2026, 3, 1)))
        // Past this month's date: roll into next month.
        assertEquals(LocalDate.of(2026, 4, 30), e.occurrenceOnOrAfter(LocalDate.of(2026, 4, 1)))
    }

    @Test
    fun `weekly events land on the same weekday`() {
        val monday = LocalDate.of(2026, 1, 5)
        val e = event(monday, Recurrence.WEEKLY)
        val sunday = LocalDate.of(2026, 3, 15)
        assertEquals(LocalDate.of(2026, 3, 16), e.occurrenceOnOrAfter(sunday))
        assertEquals(1L, e.daysRemaining(sunday))
    }

    @Test
    fun `next reminder is the earliest offset still in the future`() {
        val e = event(LocalDate.of(2026, 3, 20), offsets = setOf(0, 3))
        val now = LocalDateTime.of(2026, 3, 15, 10, 0)
        assertEquals(LocalDateTime.of(2026, 3, 17, 9, 0), e.nextReminderTrigger(now, 9))
        assertEquals(LocalDateTime.of(2026, 3, 20, 9, 0), e.nextReminderTrigger(LocalDateTime.of(2026, 3, 18, 8, 0), 9))
    }

    @Test
    fun `no reminder when none chosen or all are in the past`() {
        val now = LocalDateTime.of(2026, 3, 21, 8, 0)
        assertNull(event(LocalDate.of(2026, 3, 25)).nextReminderTrigger(now, 9))
        assertNull(event(LocalDate.of(2026, 3, 20), offsets = setOf(0, 1)).nextReminderTrigger(now, 9))
    }

    @Test
    fun `recurring events schedule the following occurrence once today's reminder has passed`() {
        val e = event(LocalDate.of(2020, 3, 20), Recurrence.YEARLY, setOf(0))
        val now = LocalDateTime.of(2026, 3, 20, 10, 0)
        assertEquals(LocalDateTime.of(2027, 3, 20, 9, 0), e.nextReminderTrigger(now, 9))
    }
}
