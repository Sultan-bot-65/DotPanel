package com.dotpanel.app.data.backup

import com.dotpanel.app.database.DashboardCardEntity
import com.dotpanel.app.database.DashboardPresetEntity
import com.dotpanel.app.database.EventEntity
import com.dotpanel.app.database.GoalCompletionEntity
import com.dotpanel.app.database.GoalEntity
import com.dotpanel.app.database.NoteEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupCodecTest {

    private fun valid() = BackupFile(
        exportedAt = 1_700_000_000_000,
        presets = listOf(DashboardPresetEntity(1, "Home")),
        cards = listOf(DashboardCardEntity(1, presetId = 1, type = "CLOCK", title = "Now", size = "LARGE", position = 0)),
        events = listOf(EventEntity(1, "Birthday", 20_000, "BIRTHDAY", "YEARLY", "0,1", "Cake")),
        notes = listOf(NoteEntity(1, "Title", "Body", "RED", pinned = true, createdAt = 1, updatedAt = 2)),
        goals = listOf(GoalEntity(1, "Read", 19_990)),
        completions = listOf(GoalCompletionEntity(1, goalId = 1, epochDay = 19_995)),
    )

    private fun assertRejected(file: BackupFile) {
        assertThrows(BackupException::class.java) { BackupCodec.decode(BackupCodec.encode(file)) }
    }

    @Test
    fun `a valid backup survives an encode and decode round trip`() {
        val file = valid()
        assertEquals(file, BackupCodec.decode(BackupCodec.encode(file)))
    }

    @Test
    fun `unknown extra keys are ignored for forward compatibility`() {
        val text = BackupCodec.encode(valid()).replaceFirst("{", "{ \"futureField\": 42,")
        assertEquals(valid(), BackupCodec.decode(text))
    }

    @Test
    fun `text that is not a backup is rejected without touching anything`() {
        assertThrows(BackupException::class.java) { BackupCodec.decode("not json at all") }
        assertThrows(BackupException::class.java) { BackupCodec.decode("{\"presets\": 3}") }
        assertThrows(BackupException::class.java) { BackupCodec.decode("") }
    }

    @Test
    fun `files from another app or a newer schema are rejected`() {
        assertRejected(valid().copy(app = "SomethingElse"))
        val newer = assertThrows(BackupException::class.java) {
            BackupCodec.decode(BackupCodec.encode(valid().copy(schemaVersion = BackupCodec.SCHEMA_VERSION + 1)))
        }
        assertTrue(newer.message!!.contains("newer"))
        assertRejected(valid().copy(schemaVersion = 0))
    }

    @Test
    fun `a backup needs at least one preset`() = assertRejected(valid().copy(presets = emptyList(), cards = emptyList()))

    @Test
    fun `cards must point at an existing preset and use known enums`() {
        val card = valid().cards.first()
        assertRejected(valid().copy(cards = listOf(card.copy(presetId = 99))))
        assertRejected(valid().copy(cards = listOf(card.copy(type = "HOLOGRAM"))))
        assertRejected(valid().copy(cards = listOf(card.copy(size = "HUGE"))))
        assertRejected(valid().copy(cards = listOf(card.copy(position = -1))))
    }

    @Test
    fun `events are validated`() {
        val event = valid().events.first()
        assertRejected(valid().copy(events = listOf(event.copy(title = "  "))))
        assertRejected(valid().copy(events = listOf(event.copy(category = "PARTY"))))
        assertRejected(valid().copy(events = listOf(event.copy(recurrence = "DAILYISH"))))
        assertRejected(valid().copy(events = listOf(event.copy(reminderOffsets = "0,abc"))))
        assertRejected(valid().copy(events = listOf(event.copy(reminderOffsets = "999"))))
        assertRejected(valid().copy(events = listOf(event.copy(dateEpochDay = Long.MAX_VALUE))))
    }

    @Test
    fun `duplicate ids are rejected`() {
        val v = valid()
        assertRejected(v.copy(events = v.events + v.events))
        assertRejected(v.copy(notes = v.notes + v.notes))
        assertRejected(v.copy(goals = v.goals + v.goals))
    }

    @Test
    fun `goal completions must reference a goal and be unique per day`() {
        val c = valid().completions.first()
        assertRejected(valid().copy(completions = listOf(c.copy(goalId = 42))))
        assertRejected(valid().copy(completions = listOf(c, c.copy(id = 2))))
    }

    @Test
    fun `notes with an unknown colour are rejected`() {
        assertRejected(valid().copy(notes = listOf(valid().notes.first().copy(color = "PLAID"))))
    }
}
