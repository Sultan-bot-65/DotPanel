package com.dotpanel.app.feature.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class NotesUiState(
    val loading: Boolean = true,
    val query: String = "",
    val pinned: List<Note> = emptyList(),
    val others: List<Note> = emptyList(),
    val totalCount: Int = 0,
) {
    val isSearching: Boolean get() = query.isNotBlank()
    val isEmpty: Boolean get() = pinned.isEmpty() && others.isEmpty()
}

@HiltViewModel
class NotesViewModel @Inject constructor(notes: NoteRepository) : ViewModel() {

    private val query = MutableStateFlow("")

    val uiState: StateFlow<NotesUiState> = combine(notes.observeNotes(), query) { all, q ->
        val needle = q.trim()
        val matches = if (needle.isEmpty()) {
            all
        } else {
            all.filter { it.title.contains(needle, ignoreCase = true) || it.content.contains(needle, ignoreCase = true) }
        }
        NotesUiState(
            loading = false,
            query = q,
            pinned = matches.filter { it.pinned },
            others = matches.filter { !it.pinned },
            totalCount = all.size,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NotesUiState())

    fun setQuery(value: String) {
        query.value = value.take(100)
    }
}
