package com.dotpanel.app.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.core.util.BatteryInfo
import com.dotpanel.app.core.util.BatteryMonitor
import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.model.AppSettings
import com.dotpanel.app.domain.model.DashboardCard
import com.dotpanel.app.domain.model.DashboardPreset
import com.dotpanel.app.domain.model.GoalStats
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.UpcomingEvent
import com.dotpanel.app.domain.repository.DashboardRepository
import com.dotpanel.app.domain.repository.EventRepository
import com.dotpanel.app.domain.repository.NoteRepository
import com.dotpanel.app.domain.repository.SettingsRepository
import com.dotpanel.app.domain.usecase.ObserveGoalStatsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardUiState(
    val loading: Boolean = true,
    val presets: List<DashboardPreset> = emptyList(),
    val activePreset: DashboardPreset? = null,
    val cards: List<DashboardCard> = emptyList(),
    val upcoming: List<UpcomingEvent> = emptyList(),
    val goals: GoalStats? = null,
    val notes: List<Note> = emptyList(),
    val battery: BatteryInfo? = null,
    val use24Hour: Boolean = true,
) {
    val visibleCards: List<DashboardCard> get() = cards.filter { it.visible }
}

private data class DashboardData(
    val upcoming: List<UpcomingEvent>,
    val goals: GoalStats,
    val notes: List<Note>,
    val battery: BatteryInfo?,
    val settings: AppSettings,
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val dashboard: DashboardRepository,
    events: EventRepository,
    notes: NoteRepository,
    observeGoalStats: ObserveGoalStatsUseCase,
    batteryMonitor: BatteryMonitor,
    dateProvider: DateProvider,
    private val settings: SettingsRepository,
) : ViewModel() {

    private val layout = combine(
        dashboard.observePresets(),
        settings.settings.map { it.activePresetId }.distinctUntilChanged(),
    ) { presets, activeId -> presets to (presets.firstOrNull { it.id == activeId } ?: presets.firstOrNull()) }

    private val cards = layout.flatMapLatest { (_, active) ->
        if (active == null) flowOf(emptyList()) else dashboard.observeCards(active.id)
    }

    private val data = combine(
        combine(events.observeEvents(), dateProvider.todayFlow) { list, today ->
            list.map { it.toUpcoming(today) }.filter { !it.passed }.sortedBy { it.daysRemaining }.take(5)
        },
        observeGoalStats(),
        notes.observeNotes().map { it.take(4) },
        batteryMonitor.batteryInfo,
        settings.settings,
    ) { upcoming, goals, noteList, battery, s -> DashboardData(upcoming, goals, noteList, battery, s) }

    val uiState: StateFlow<DashboardUiState> = combine(layout, cards, data) { (presets, active), cardList, d ->
        DashboardUiState(
            loading = false,
            presets = presets,
            activePreset = active,
            cards = cardList,
            upcoming = d.upcoming,
            goals = d.goals,
            notes = d.notes,
            battery = d.battery,
            use24Hour = d.settings.use24HourClock,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardUiState())

    fun selectPreset(id: Long) {
        viewModelScope.launch { settings.setActivePresetId(id) }
    }
}
