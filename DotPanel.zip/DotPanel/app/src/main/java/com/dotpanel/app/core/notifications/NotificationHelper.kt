package com.dotpanel.app.core.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.dotpanel.app.R
import com.dotpanel.app.core.util.deepLinkIntent
import com.dotpanel.app.core.util.daysLabel
import com.dotpanel.app.domain.model.Event
import com.dotpanel.app.navigation.Routes
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(@ApplicationContext private val context: Context) {

    init {
        createChannels()
    }

    fun canPost(): Boolean {
        val permitted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        return permitted && NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun notifyEvent(event: Event, daysRemaining: Long) {
        if (!canPost()) return
        val text = when (daysRemaining) {
            0L -> "Today"
            1L -> "Tomorrow"
            else -> daysLabel(daysRemaining) + " to go"
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_EVENTS)
            .setSmallIcon(R.drawable.ic_stat_dot)
            .setContentTitle(event.title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openRoute(Routes.event(event.id)))
            .build()
        post(EVENT_NOTIFICATION_BASE + event.id.toInt(), notification)
    }

    fun notifyGoals(remaining: Int, total: Int) {
        if (!canPost()) return
        val notification = NotificationCompat.Builder(context, CHANNEL_GOALS)
            .setSmallIcon(R.drawable.ic_stat_dot)
            .setContentTitle("Daily goals")
            .setContentText("$remaining of $total goals still to do today")
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openRoute(Routes.GOALS))
            .build()
        post(GOAL_NOTIFICATION_ID, notification)
    }

    @Suppress("MissingPermission") // canPost() verified the permission above
    private fun post(id: Int, notification: android.app.Notification) {
        NotificationManagerCompat.from(context).notify(id, notification)
    }

    private fun openRoute(route: String): PendingIntent =
        PendingIntent.getActivity(
            context,
            route.hashCode(),
            deepLinkIntent(context, route),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_EVENTS,
                context.getString(R.string.channel_events_name),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply { description = context.getString(R.string.channel_events_desc) },
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_GOALS,
                context.getString(R.string.channel_goals_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply { description = context.getString(R.string.channel_goals_desc) },
        )
    }

    private companion object {
        const val CHANNEL_EVENTS = "events"
        const val CHANNEL_GOALS = "goals"
        const val GOAL_NOTIFICATION_ID = 1
        const val EVENT_NOTIFICATION_BASE = 1000
    }
}
