package com.dotpanel.app.data.repository

import androidx.room.withTransaction
import com.dotpanel.app.data.toDomain
import com.dotpanel.app.data.toEntity
import com.dotpanel.app.database.DashboardDao
import com.dotpanel.app.database.DashboardPresetEntity
import com.dotpanel.app.database.DotPanelDatabase
import com.dotpanel.app.domain.model.DashboardCard
import com.dotpanel.app.domain.model.DashboardPreset
import com.dotpanel.app.domain.model.DefaultDashboard
import com.dotpanel.app.domain.repository.DashboardRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Singleton
class DashboardRepositoryImpl @Inject constructor(
    private val db: DotPanelDatabase,
    private val dao: DashboardDao,
) : DashboardRepository {

    override fun observePresets(): Flow<List<DashboardPreset>> =
        dao.observePresets().map { list -> list.map { it.toDomain() } }

    override fun observeCards(presetId: Long): Flow<List<DashboardCard>> =
        dao.observeCards(presetId).map { list -> list.map { it.toDomain() } }

    override suspend fun ensureDefaults() {
        db.withTransaction {
            if (dao.presetCount() == 0) createPreset("Home", withDefaultCards = true)
        }
    }

    override suspend fun createPreset(name: String, withDefaultCards: Boolean): Long =
        db.withTransaction {
            val id = dao.insertPreset(DashboardPresetEntity(name = name.trim().take(60).ifBlank { "Preset" }))
            if (withDefaultCards) dao.insertCards(DefaultDashboard.cards(id).map { it.toEntity() })
            id
        }

    override suspend fun renamePreset(id: Long, name: String) {
        dao.renamePreset(id, name.trim().take(60).ifBlank { return })
    }

    override suspend fun deletePreset(id: Long) {
        db.withTransaction {
            // Never delete the last preset: the dashboard always needs one to show.
            if (dao.presetCount() > 1) dao.deletePreset(id)
        }
    }

    override suspend fun addCard(card: DashboardCard): Long =
        db.withTransaction {
            dao.insertCard(card.copy(id = 0, position = dao.maxPosition(card.presetId) + 1).toEntity())
        }

    override suspend fun updateCard(card: DashboardCard) = dao.updateCard(card.toEntity())

    override suspend fun deleteCard(id: Long) = dao.deleteCard(id)

    override suspend fun saveOrder(orderedCardIds: List<Long>) {
        db.withTransaction {
            orderedCardIds.forEachIndexed { index, id -> dao.updatePosition(id, index) }
        }
    }
}
