package com.dotpanel.app.widgets

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.width
import androidx.glance.text.Text
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.NoteColor
import com.dotpanel.app.domain.model.WidgetConfig
import com.dotpanel.app.navigation.Routes

/** One note at a glance: the one chosen in the widget settings, or else the latest (pinned notes first). */
class NotesWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val entry = context.widgetEntryPoint()
        val appWidgetId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val config = entry.widgetConfigs().get(appWidgetId)
        val note = NoteSelection.choose(entry.notes().getNotes(), config)

        provideContent {
            val size = LocalSize.current
            WidgetFrame(onClick = openRoute(Routes.note(note?.id ?: Routes.NEW_ID))) {
                if (note == null) EmptyNote() else NoteContent(note, size.height - 24.dp)
            }
        }
    }
}

/** Pure selection rule, separated so it can be unit-tested without Android. */
internal object NoteSelection {
    fun choose(all: List<Note>, config: WidgetConfig?): Note? {
        val chosen = config?.targetId?.takeIf { it != WidgetConfig.NO_TARGET }
            ?.let { id -> all.firstOrNull { it.id == id } }
        return chosen ?: all.filter { !it.isBlank }
            .maxWithOrNull(compareBy<Note>({ it.pinned }, { it.updatedAt }))
    }
}

@Composable
private fun EmptyNote() {
    Column(modifier = GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Text("NO NOTES", style = widgetText(size = 14.sp, bold = true))
        Spacer(GlanceModifier.height(4.dp))
        Text("Tap to write one", style = widgetText(WidgetColors.textSecondary, 11.sp))
    }
}

@Composable
private fun NoteContent(note: Note, innerHeight: Dp) {
    // Title and header take ~44dp; the remaining height is filled with body text at ~16dp per line.
    val bodyLines = ((innerHeight.value - 44f) / 16f).toInt().coerceIn(1, 12)
    val body = if (note.title.isBlank()) {
        note.content.lineSequence().drop(1).joinToString("\n").trim()
    } else {
        note.content.trim()
    }
    Column(modifier = GlanceModifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Dot(
                if (note.color == NoteColor.NONE) WidgetColors.accent else WidgetColors.fixed(Color(note.color.argb)),
                size = 8.dp,
            )
            Spacer(GlanceModifier.width(6.dp))
            Text(
                if (note.pinned) "PINNED NOTE" else "NOTE",
                style = widgetText(WidgetColors.textSecondary, 10.sp),
                maxLines = 1,
            )
        }
        Spacer(GlanceModifier.height(6.dp))
        Text(note.displayTitle, style = widgetText(size = 14.sp, bold = true), maxLines = 2)
        if (body.isNotEmpty()) {
            Spacer(GlanceModifier.height(4.dp))
            Text(body, style = widgetText(WidgetColors.textSecondary, 12.sp), maxLines = bodyLines)
        }
    }
}

class NotesWidgetReceiver : DotPanelWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = NotesWidget()
}
