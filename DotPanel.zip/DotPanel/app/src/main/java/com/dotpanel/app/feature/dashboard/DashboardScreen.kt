package com.dotpanel.app.feature.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.designsystem.DotChip
import com.dotpanel.app.designsystem.DotIconButton
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.EmptyState
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.domain.model.CardSize

@Composable
fun DashboardScreen(
    onNavigate: (String) -> Unit,
    onEditLayout: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: DashboardViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier.fillMaxSize().statusBarsPadding()) {
        ScreenHeader(
            title = "DotPanel",
            subtitle = "Your Life. Your Dashboard.",
            actions = { DotIconButton(Icons.Outlined.Tune, "Edit dashboard layout", onEditLayout) },
        )
        if (state.presets.size > 1) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(state.presets, key = { it.id }) { preset ->
                    DotChip(preset.name, selected = preset.id == state.activePreset?.id, onClick = { viewModel.selectPreset(preset.id) })
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        val cards = state.visibleCards
        if (!state.loading && cards.isEmpty()) {
            EmptyState(
                message = "This dashboard has no visible cards.",
                hint = "Tap the sliders icon to add some",
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(
                    items = cards,
                    key = { it.id },
                    span = { card -> GridItemSpan(if (card.size == CardSize.SMALL) 1 else 2) },
                ) { card ->
                    DashboardCardView(card = card, state = state, onNavigate = onNavigate)
                }
            }
        }
    }
}
