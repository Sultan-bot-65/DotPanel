package com.dotpanel.app.widgets

import android.content.Context
import com.dotpanel.app.core.di.ApplicationScope
import com.dotpanel.app.domain.repository.WidgetRefresher
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.updateAll

/**
 * Redraws the data-driven widgets after the database changes.
 *
 * Repositories call [requestRefresh] after every write. Requests are debounced, so a burst of edits
 * (typing in a note, importing a backup) produces a single redraw, which keeps battery use low. The
 * clock widget is deliberately absent: its TextClock ticks by itself with no updates at all.
 */
@OptIn(FlowPreview::class)
@Singleton
class GlanceWidgetRefresher @Inject constructor(
    @ApplicationContext private val context: Context,
    @ApplicationScope scope: CoroutineScope,
) : WidgetRefresher {

    private val requests = MutableSharedFlow<Unit>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    init {
        scope.launch {
            requests.debounce(DEBOUNCE_MS).collect { updateAllWidgets() }
        }
    }

    override fun requestRefresh() {
        requests.tryEmit(Unit)
    }

    private suspend fun updateAllWidgets() {
        refresh(CountdownWidget())
        refresh(GoalsWidget())
        refresh(NotesWidget())
        refresh(SummaryWidget())
    }

    private suspend fun refresh(widget: GlanceAppWidget) {
        try {
            widget.updateAll(context)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // A widget that fails to redraw must never take the app down; the next update retries.
        }
    }

    private companion object {
        const val DEBOUNCE_MS = 400L
    }
}
