package com.dotpanel.app.feature.events

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.model.EventCategory
import com.dotpanel.app.domain.model.UpcomingEvent
import com.dotpanel.app.domain.repository.EventRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class EventsUiState(
    val loading: Boolean = true,
    val upcoming: List<UpcomingEvent> = emptyList(),
    val passed: List<UpcomingEvent> = emptyList(),
    val filter: EventCategory? = null,
) {
    val isEmpty: Boolean get() = upcoming.isEmpty() && passed.isEmpty()
}

@HiltViewModel
class EventsViewModel @Inject constructor(
    events: EventRepository,
    dateProvider: DateProvider,
) : ViewModel() {

    private val filter = MutableStateFlow<EventCategory?>(null)

    val uiState: StateFlow<EventsUiState> =
        combine(events.observeEvents(), dateProvider.todayFlow, filter) { list, today, category ->
            val items = list
                .filter { category == null || it.category == category }
                .map { it.toUpcoming(today) }
            EventsUiState(
                loading = false,
                upcoming = items.filter { !it.passed }.sortedBy { it.daysRemaining },
                // Most recently passed first.
                passed = items.filter { it.passed }.sortedByDescending { it.daysRemaining },
                filter = category,
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EventsUiState())

    fun setFilter(category: EventCategory?) {
        filter.value = category
    }
}
