package com.dotpanel.app.data.repository

import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.data.toDomain
import com.dotpanel.app.database.GoalCompletionEntity
import com.dotpanel.app.database.GoalDao
import com.dotpanel.app.database.GoalEntity
import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.model.GoalCompletion
import com.dotpanel.app.domain.repository.GoalRepository
import com.dotpanel.app.domain.repository.WidgetRefresher
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Singleton
class GoalRepositoryImpl @Inject constructor(
    private val dao: GoalDao,
    private val dateProvider: DateProvider,
    private val widgets: WidgetRefresher,
) : GoalRepository {

    override fun observeGoals(): Flow<List<Goal>> = dao.observeActive().map { list -> list.map { it.toDomain() } }

    override fun observeCompletions(): Flow<List<GoalCompletion>> =
        dao.observeCompletions().map { list -> list.map { it.toDomain() } }

    override suspend fun getGoals(): List<Goal> = dao.getActive().map { it.toDomain() }

    override suspend fun getCompletions(): List<GoalCompletion> = dao.getCompletions().map { it.toDomain() }

    override suspend fun addGoal(title: String): Long {
        val id = dao.insert(
            GoalEntity(title = title.trim().take(120), createdEpochDay = dateProvider.today().toEpochDay()),
        )
        widgets.requestRefresh()
        return id
    }

    override suspend fun removeGoal(id: Long) {
        dao.archive(id)
        widgets.requestRefresh()
    }

    override suspend fun setCompleted(goalId: Long, epochDay: Long, completed: Boolean) {
        if (completed) {
            dao.insertCompletion(GoalCompletionEntity(goalId = goalId, epochDay = epochDay))
        } else {
            dao.deleteCompletion(goalId, epochDay)
        }
        widgets.requestRefresh()
    }
}
