package com.dotpanel.app.core.di

import android.content.Context
import androidx.room.Room
import androidx.work.WorkManager
import com.dotpanel.app.database.DashboardDao
import com.dotpanel.app.database.DotPanelDatabase
import com.dotpanel.app.database.DotPanelMigrations
import com.dotpanel.app.database.EventDao
import com.dotpanel.app.database.GoalDao
import com.dotpanel.app.database.NoteDao
import com.dotpanel.app.database.WidgetConfigDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    @ApplicationScope
    fun provideApplicationScope(): CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): DotPanelDatabase =
        Room.databaseBuilder(context, DotPanelDatabase::class.java, DotPanelDatabase.NAME)
            .addMigrations(*DotPanelMigrations.ALL)
            .build()

    @Provides fun provideDashboardDao(db: DotPanelDatabase): DashboardDao = db.dashboardDao()
    @Provides fun provideEventDao(db: DotPanelDatabase): EventDao = db.eventDao()
    @Provides fun provideNoteDao(db: DotPanelDatabase): NoteDao = db.noteDao()
    @Provides fun provideGoalDao(db: DotPanelDatabase): GoalDao = db.goalDao()
    @Provides fun provideWidgetConfigDao(db: DotPanelDatabase): WidgetConfigDao = db.widgetConfigDao()

    @Provides
    @Singleton
    fun provideWorkManager(@ApplicationContext context: Context): WorkManager = WorkManager.getInstance(context)
}
