package com.dotpanel.app.feature.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.BuildConfig
import com.dotpanel.app.core.notifications.openNotificationSettings
import com.dotpanel.app.core.notifications.rememberNotificationPermission
import com.dotpanel.app.designsystem.DotButton
import com.dotpanel.app.designsystem.DotCard
import com.dotpanel.app.designsystem.DotChip
import com.dotpanel.app.designsystem.DotDialog
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.HourStepper
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.designsystem.SwitchRow
import com.dotpanel.app.domain.model.ThemeMode
import java.time.LocalDate

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings = state.settings
    val colors = DotTheme.colors
    val context = LocalContext.current

    // Goal reminders need the notification permission; remember that the user just asked for them.
    var wantsGoalReminder by remember { mutableStateOf(false) }
    var notificationsBlocked by remember { mutableStateOf(false) }
    val notificationPermission = rememberNotificationPermission { granted ->
        notificationsBlocked = !granted
        if (granted && wantsGoalReminder) viewModel.setGoalReminderEnabled(true)
        wantsGoalReminder = false
    }

    // Backup: the system file picker decides where files live, so DotPanel needs no storage permission.
    var pendingImportUri by rememberSaveable { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> if (uri != null) viewModel.export(uri.toString()) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) pendingImportUri = uri.toString() }

    Column(modifier.fillMaxSize().statusBarsPadding()) {
        ScreenHeader(title = "Settings")

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            DotCard(Modifier.fillMaxWidth()) {
                DotLabel("Appearance")
                Spacer(Modifier.height(12.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        DotChip(mode.label, settings.themeMode == mode, { viewModel.setThemeMode(mode) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                SwitchRow(
                    label = "24-hour clock",
                    checked = settings.use24HourClock,
                    onCheckedChange = viewModel::setUse24HourClock,
                    description = "Used for clocks and reminder times in the app",
                )
            }

            DotCard(Modifier.fillMaxWidth()) {
                DotLabel("Reminders")
                Spacer(Modifier.height(12.dp))
                Text("Event reminders", style = MaterialTheme.typography.bodyLarge, color = colors.textPrimary)
                Text(
                    "Sent at this time on the days you choose for each event.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                )
                Spacer(Modifier.height(8.dp))
                HourStepper(settings.eventReminderHour, settings.use24HourClock, viewModel::setEventReminderHour)

                Spacer(Modifier.height(16.dp))
                SwitchRow(
                    label = "Daily goal reminder",
                    checked = settings.goalReminderEnabled,
                    onCheckedChange = { enabled ->
                        when {
                            !enabled -> viewModel.setGoalReminderEnabled(false)
                            notificationPermission.isGranted -> viewModel.setGoalReminderEnabled(true)
                            else -> {
                                wantsGoalReminder = true
                                notificationPermission.request()
                            }
                        }
                    },
                    description = "Only when you still have unfinished goals",
                )
                if (settings.goalReminderEnabled) {
                    Spacer(Modifier.height(8.dp))
                    HourStepper(settings.goalReminderHour, settings.use24HourClock, viewModel::setGoalReminderHour)
                }
                if (notificationsBlocked) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Notifications are turned off for DotPanel, so reminders can't be shown.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.accent,
                    )
                    Spacer(Modifier.height(8.dp))
                    DotButton("Notification settings", { openNotificationSettings(context) }, filled = false)
                }
            }

            DotCard(Modifier.fillMaxWidth()) {
                DotLabel("Backup")
                Spacer(Modifier.height(8.dp))
                Text(
                    "Save everything to a JSON file you control, or restore from one. " +
                        "Restoring replaces the data currently in the app.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    DotButton(
                        "Export",
                        { exportLauncher.launch("dotpanel-backup-${LocalDate.now()}.json") },
                        enabled = !state.busy,
                    )
                    DotButton(
                        "Import",
                        { importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                        filled = false,
                        enabled = !state.busy,
                    )
                }
                state.message?.let { message ->
                    Spacer(Modifier.height(12.dp))
                    Text(message, style = MaterialTheme.typography.bodySmall, color = colors.textPrimary)
                }
            }

            DotCard(Modifier.fillMaxWidth()) {
                DotLabel("Privacy")
                Spacer(Modifier.height(8.dp))
                Text(
                    "Everything stays on this device. DotPanel has no account, no analytics and no network " +
                        "access, and its only permission is showing reminder notifications.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                )
                Spacer(Modifier.height(12.dp))
                DotLabel("DotPanel ${BuildConfig.VERSION_NAME}")
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    pendingImportUri?.let { uri ->
        DotDialog(
            title = "Restore backup",
            onDismiss = { pendingImportUri = null },
            confirmText = "Replace data",
            onConfirm = {
                viewModel.import(uri)
                pendingImportUri = null
            },
        ) {
            Text(
                "This replaces your current layouts, events, notes and goals with the contents of the file. " +
                    "Export first if you want to keep what you have now.",
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
            )
        }
    }
}
