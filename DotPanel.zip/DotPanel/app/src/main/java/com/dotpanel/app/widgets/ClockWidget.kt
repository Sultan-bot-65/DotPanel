package com.dotpanel.app.widgets

import android.content.Context
import android.text.format.DateFormat
import android.widget.RemoteViews
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.appwidget.AndroidRemoteViews
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.fillMaxSize
import com.dotpanel.app.R
import com.dotpanel.app.navigation.Routes

/**
 * Large digital clock and date.
 *
 * The time is a platform TextClock inside the widget, so the system redraws it every minute by
 * itself and DotPanel runs no timers, alarms or background work for this widget.
 */
class ClockWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val appWidgetId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val stored = context.widgetEntryPoint().widgetConfigs().get(appWidgetId)
        val use24Hour = stored?.use24Hour ?: DateFormat.is24HourFormat(context)

        provideContent {
            val size = LocalSize.current
            val large = size.width >= LARGE_MIN_WIDTH && size.height >= LARGE_MIN_HEIGHT
            val views = RemoteViews(
                context.packageName,
                if (large) R.layout.widget_clock_large else R.layout.widget_clock_small,
            ).apply {
                // Forcing both patterns makes the per-widget choice win over the system setting.
                val time = if (use24Hour) "HH:mm" else "h:mm"
                setCharSequence(R.id.clock_time, "setFormat12Hour", time)
                setCharSequence(R.id.clock_time, "setFormat24Hour", time)
            }
            WidgetFrame(onClick = openRoute(Routes.DASHBOARD)) {
                Box(modifier = GlanceModifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidRemoteViews(remoteViews = views, modifier = GlanceModifier.fillMaxSize())
                }
            }
        }
    }

    private companion object {
        val LARGE_MIN_WIDTH = 230.dp
        val LARGE_MIN_HEIGHT = 110.dp
    }
}

class ClockWidgetReceiver : DotPanelWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ClockWidget()
}
