package com.dotpanel.app.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface DashboardDao {
    @Query("SELECT * FROM dashboard_presets ORDER BY id")
    fun observePresets(): Flow<List<DashboardPresetEntity>>

    @Query("SELECT * FROM dashboard_cards WHERE presetId = :presetId ORDER BY position, id")
    fun observeCards(presetId: Long): Flow<List<DashboardCardEntity>>

    @Query("SELECT COUNT(*) FROM dashboard_presets")
    suspend fun presetCount(): Int

    @Query("SELECT * FROM dashboard_presets ORDER BY id")
    suspend fun getPresets(): List<DashboardPresetEntity>

    @Query("SELECT * FROM dashboard_cards ORDER BY presetId, position, id")
    suspend fun getCards(): List<DashboardCardEntity>

    @Insert
    suspend fun insertPreset(preset: DashboardPresetEntity): Long

    @Query("UPDATE dashboard_presets SET name = :name WHERE id = :id")
    suspend fun renamePreset(id: Long, name: String)

    @Query("DELETE FROM dashboard_presets WHERE id = :id")
    suspend fun deletePreset(id: Long)

    @Insert
    suspend fun insertCard(card: DashboardCardEntity): Long

    @Insert
    suspend fun insertCards(cards: List<DashboardCardEntity>)

    @Update
    suspend fun updateCard(card: DashboardCardEntity)

    @Query("DELETE FROM dashboard_cards WHERE id = :id")
    suspend fun deleteCard(id: Long)

    @Query("SELECT COALESCE(MAX(position), -1) FROM dashboard_cards WHERE presetId = :presetId")
    suspend fun maxPosition(presetId: Long): Int

    @Query("UPDATE dashboard_cards SET position = :position WHERE id = :id")
    suspend fun updatePosition(id: Long, position: Int)

    // Backup restore
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restorePresets(items: List<DashboardPresetEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreCards(items: List<DashboardCardEntity>)

    @Query("DELETE FROM dashboard_presets")
    suspend fun clearPresets()
}

@Dao
interface EventDao {
    @Query("SELECT * FROM events ORDER BY dateEpochDay, id")
    fun observeAll(): Flow<List<EventEntity>>

    @Query("SELECT * FROM events ORDER BY dateEpochDay, id")
    suspend fun getAll(): List<EventEntity>

    @Query("SELECT * FROM events WHERE id = :id")
    suspend fun get(id: Long): EventEntity?

    /** Returns the new row id on insert, or -1 when an existing row was updated. */
    @Upsert
    suspend fun upsert(event: EventEntity): Long

    @Query("DELETE FROM events WHERE id = :id")
    suspend fun delete(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restore(items: List<EventEntity>)

    @Query("DELETE FROM events")
    suspend fun clear()
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY pinned DESC, updatedAt DESC")
    suspend fun getAll(): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun get(id: Long): NoteEntity?

    @Upsert
    suspend fun upsert(note: NoteEntity): Long

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun delete(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restore(items: List<NoteEntity>)

    @Query("DELETE FROM notes")
    suspend fun clear()
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals WHERE archived = 0 ORDER BY createdEpochDay, id")
    fun observeActive(): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals WHERE archived = 0 ORDER BY createdEpochDay, id")
    suspend fun getActive(): List<GoalEntity>

    @Query("SELECT * FROM goals ORDER BY id")
    suspend fun getAll(): List<GoalEntity>

    @Insert
    suspend fun insert(goal: GoalEntity): Long

    @Query("UPDATE goals SET archived = 1 WHERE id = :id")
    suspend fun archive(id: Long)

    @Query("SELECT * FROM goal_completions")
    fun observeCompletions(): Flow<List<GoalCompletionEntity>>

    @Query("SELECT * FROM goal_completions")
    suspend fun getCompletions(): List<GoalCompletionEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCompletion(completion: GoalCompletionEntity)

    @Query("DELETE FROM goal_completions WHERE goalId = :goalId AND epochDay = :epochDay")
    suspend fun deleteCompletion(goalId: Long, epochDay: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreGoals(items: List<GoalEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreCompletions(items: List<GoalCompletionEntity>)

    @Query("DELETE FROM goals")
    suspend fun clearGoals()
}

@Dao
interface WidgetConfigDao {
    @Query("SELECT * FROM widget_configurations WHERE appWidgetId = :id")
    suspend fun get(id: Int): WidgetConfigurationEntity?

    @Upsert
    suspend fun upsert(config: WidgetConfigurationEntity)

    @Query("DELETE FROM widget_configurations WHERE appWidgetId IN (:ids)")
    suspend fun delete(ids: List<Int>)
}
