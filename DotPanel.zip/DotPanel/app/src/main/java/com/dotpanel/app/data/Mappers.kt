package com.dotpanel.app.data

import com.dotpanel.app.database.DashboardCardEntity
import com.dotpanel.app.database.DashboardPresetEntity
import com.dotpanel.app.database.EventEntity
import com.dotpanel.app.database.GoalCompletionEntity
import com.dotpanel.app.database.GoalEntity
import com.dotpanel.app.database.NoteEntity
import com.dotpanel.app.database.WidgetConfigurationEntity
import com.dotpanel.app.domain.model.CardSize
import com.dotpanel.app.domain.model.CardType
import com.dotpanel.app.domain.model.DashboardCard
import com.dotpanel.app.domain.model.DashboardPreset
import com.dotpanel.app.domain.model.Event
import com.dotpanel.app.domain.model.EventCategory
import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.model.GoalCompletion
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.NoteColor
import com.dotpanel.app.domain.model.Recurrence
import com.dotpanel.app.domain.model.WidgetConfig
import com.dotpanel.app.domain.model.WidgetType
import java.time.LocalDate

/** Parses an enum stored by name, falling back to [default] so unknown values never crash. */
internal inline fun <reified T : Enum<T>> String.toEnumOrDefault(default: T): T =
    enumValues<T>().firstOrNull { it.name == this } ?: default

internal fun DashboardPresetEntity.toDomain() = DashboardPreset(id, name)

internal fun DashboardCardEntity.toDomain() = DashboardCard(
    id = id,
    presetId = presetId,
    type = type.toEnumOrDefault(CardType.CUSTOM_TEXT),
    title = title,
    content = content,
    size = size.toEnumOrDefault(CardSize.MEDIUM),
    position = position,
    visible = visible,
)

internal fun DashboardCard.toEntity() = DashboardCardEntity(
    id = id,
    presetId = presetId,
    type = type.name,
    title = title,
    content = content,
    size = size.name,
    position = position,
    visible = visible,
)

internal fun parseOffsets(raw: String): Set<Int> =
    if (raw.isBlank()) emptySet() else raw.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet()

internal fun EventEntity.toDomain() = Event(
    id = id,
    title = title,
    date = LocalDate.ofEpochDay(dateEpochDay),
    category = category.toEnumOrDefault(EventCategory.OTHER),
    recurrence = recurrence.toEnumOrDefault(Recurrence.NONE),
    reminderOffsets = parseOffsets(reminderOffsets),
    notes = notes,
)

internal fun Event.toEntity() = EventEntity(
    id = id,
    title = title,
    dateEpochDay = date.toEpochDay(),
    category = category.name,
    recurrence = recurrence.name,
    reminderOffsets = reminderOffsets.sorted().joinToString(","),
    notes = notes,
)

internal fun NoteEntity.toDomain() = Note(
    id = id,
    title = title,
    content = content,
    color = color.toEnumOrDefault(NoteColor.NONE),
    pinned = pinned,
    createdAt = createdAt,
    updatedAt = updatedAt,
)

internal fun Note.toEntity() = NoteEntity(
    id = id,
    title = title,
    content = content,
    color = color.name,
    pinned = pinned,
    createdAt = createdAt,
    updatedAt = updatedAt,
)

internal fun GoalEntity.toDomain() = Goal(id, title, createdEpochDay)
internal fun GoalCompletionEntity.toDomain() = GoalCompletion(goalId, epochDay)

internal fun WidgetConfigurationEntity.toDomain() = WidgetConfig(
    appWidgetId = appWidgetId,
    type = widgetType.toEnumOrDefault(WidgetType.SUMMARY),
    targetId = targetId,
    use24Hour = use24Hour,
    hideCompleted = hideCompleted,
)

internal fun WidgetConfig.toEntity() = WidgetConfigurationEntity(
    appWidgetId = appWidgetId,
    widgetType = type.name,
    targetId = targetId,
    use24Hour = use24Hour,
    hideCompleted = hideCompleted,
)
