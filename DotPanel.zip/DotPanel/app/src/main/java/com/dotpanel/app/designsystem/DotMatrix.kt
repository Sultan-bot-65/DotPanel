package com.dotpanel.app.designsystem

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.min
import kotlin.math.roundToInt

/** 5x7 dot-matrix font. Each glyph is seven rows of five columns ('1' = lit dot). */
private val GLYPH_SOURCE: Map<Char, String> = mapOf(
    ' ' to "00000 00000 00000 00000 00000 00000 00000",
    '0' to "01110 10001 10011 10101 11001 10001 01110",
    '1' to "00100 01100 00100 00100 00100 00100 01110",
    '2' to "01110 10001 00001 00010 00100 01000 11111",
    '3' to "11110 00001 00001 01110 00001 00001 11110",
    '4' to "00010 00110 01010 10010 11111 00010 00010",
    '5' to "11111 10000 11110 00001 00001 10001 01110",
    '6' to "00110 01000 10000 11110 10001 10001 01110",
    '7' to "11111 00001 00010 00100 01000 01000 01000",
    '8' to "01110 10001 10001 01110 10001 10001 01110",
    '9' to "01110 10001 10001 01111 00001 00010 01100",
    'A' to "01110 10001 10001 11111 10001 10001 10001",
    'B' to "11110 10001 10001 11110 10001 10001 11110",
    'C' to "01110 10001 10000 10000 10000 10001 01110",
    'D' to "11110 10001 10001 10001 10001 10001 11110",
    'E' to "11111 10000 10000 11110 10000 10000 11111",
    'F' to "11111 10000 10000 11110 10000 10000 10000",
    'G' to "01110 10001 10000 10111 10001 10001 01111",
    'H' to "10001 10001 10001 11111 10001 10001 10001",
    'I' to "01110 00100 00100 00100 00100 00100 01110",
    'J' to "00111 00010 00010 00010 00010 10010 01100",
    'K' to "10001 10010 10100 11000 10100 10010 10001",
    'L' to "10000 10000 10000 10000 10000 10000 11111",
    'M' to "10001 11011 10101 10101 10001 10001 10001",
    'N' to "10001 11001 10101 10011 10001 10001 10001",
    'O' to "01110 10001 10001 10001 10001 10001 01110",
    'P' to "11110 10001 10001 11110 10000 10000 10000",
    'Q' to "01110 10001 10001 10001 10101 10010 01101",
    'R' to "11110 10001 10001 11110 10100 10010 10001",
    'S' to "01111 10000 10000 01110 00001 00001 11110",
    'T' to "11111 00100 00100 00100 00100 00100 00100",
    'U' to "10001 10001 10001 10001 10001 10001 01110",
    'V' to "10001 10001 10001 10001 10001 01010 00100",
    'W' to "10001 10001 10001 10101 10101 10101 01010",
    'X' to "10001 10001 01010 00100 01010 10001 10001",
    'Y' to "10001 10001 01010 00100 00100 00100 00100",
    'Z' to "11111 00001 00010 00100 01000 10000 11111",
    ':' to "00000 00100 00100 00000 00100 00100 00000",
    '-' to "00000 00000 00000 11111 00000 00000 00000",
    '.' to "00000 00000 00000 00000 00000 01100 01100",
    ',' to "00000 00000 00000 00000 01100 00100 01000",
    '/' to "00001 00001 00010 00100 01000 10000 10000",
    '%' to "11001 11001 00010 00100 01000 10011 10011",
    '+' to "00000 00100 00100 11111 00100 00100 00000",
    '!' to "00100 00100 00100 00100 00100 00000 00100",
    '?' to "01110 10001 00001 00010 00100 00000 00100",
)

internal const val ROWS = 7
internal const val COLS = 5

internal val GLYPHS: Map<Char, BooleanArray> = GLYPH_SOURCE.mapValues { (_, rows) ->
    rows.replace(" ", "").map { it == '1' }.toBooleanArray()
}

/**
 * Draws [text] as a dot-matrix display. Unlit dots are drawn faintly, like a real LED panel.
 * Lower-case is upper-cased; unsupported characters render as '?'.
 */
@Composable
fun DotText(
    text: String,
    modifier: Modifier = Modifier,
    dotSize: Dp = 4.dp,
    gap: Dp = 1.5.dp,
    color: Color = DotTheme.colors.textPrimary,
    offColor: Color = color.copy(alpha = 0.08f),
    showOffDots: Boolean = true,
) {
    val chars = remember(text) { text.uppercase() }
    val columns = if (chars.isEmpty()) 0 else chars.length * (COLS + 1) - 1
    val pitch = dotSize + gap
    Canvas(
        modifier
            .size(
                width = (pitch * columns - gap).coerceAtLeast(0.dp),
                height = pitch * ROWS - gap,
            )
            .semantics { contentDescription = text },
    ) {
        val p = pitch.toPx()
        val r = dotSize.toPx() / 2f
        chars.forEachIndexed { index, ch ->
            val glyph = GLYPHS[ch] ?: GLYPHS.getValue('?')
            for (row in 0 until ROWS) {
                for (col in 0 until COLS) {
                    val lit = glyph[row * COLS + col]
                    if (!lit && !showOffDots) continue
                    drawCircle(
                        color = if (lit) color else offColor,
                        radius = r,
                        center = Offset((index * (COLS + 1) + col) * p + r, row * p + r),
                    )
                }
            }
        }
    }
}

/** A [DotText] that scales its dots so the whole string exactly fits the available width. */
@Composable
fun DotTextFit(
    text: String,
    modifier: Modifier = Modifier,
    maxDotSize: Dp = 10.dp,
    color: Color = DotTheme.colors.textPrimary,
) {
    BoxWithConstraints(modifier) {
        val columns = (text.length * (COLS + 1) - 1).coerceAtLeast(1)
        val maxPitch = maxDotSize / 0.72f
        val pitch = if (constraints.hasBoundedWidth) (maxWidth / columns).coerceAtMost(maxPitch) else maxPitch
        DotText(text = text, dotSize = pitch * 0.72f, gap = pitch * 0.28f, color = color)
    }
}

/** Progress shown as a row of dots; the filled ones use the accent colour. */
@Composable
fun DotProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    segments: Int = 24,
    height: Dp = 8.dp,
    color: Color = DotTheme.colors.accent,
    offColor: Color = DotTheme.colors.border,
) {
    Canvas(modifier.fillMaxWidth().height(height)) {
        val pitch = size.width / segments
        val radius = min(pitch * 0.32f, size.height / 2f)
        val filled = (progress.coerceIn(0f, 1f) * segments).roundToInt()
        for (i in 0 until segments) {
            drawCircle(
                color = if (i < filled) color else offColor,
                radius = radius,
                center = Offset(pitch * i + pitch / 2f, size.height / 2f),
            )
        }
    }
}
