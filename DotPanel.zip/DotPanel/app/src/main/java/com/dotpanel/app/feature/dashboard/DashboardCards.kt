package com.dotpanel.app.feature.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.dotpanel.app.core.util.daysLabel
import com.dotpanel.app.core.util.daysShort
import com.dotpanel.app.core.util.formatDayMonth
import com.dotpanel.app.designsystem.AccentDot
import com.dotpanel.app.designsystem.DotCard
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotProgressBar
import com.dotpanel.app.designsystem.DotText
import com.dotpanel.app.designsystem.DotTextFit
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.domain.model.CardSize
import com.dotpanel.app.domain.model.CardType
import com.dotpanel.app.domain.model.DashboardCard
import com.dotpanel.app.navigation.Routes
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay

/** Renders one dashboard card. Every card type has a layout for each of the three sizes. */
@Composable
fun DashboardCardView(
    card: DashboardCard,
    state: DashboardUiState,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val sizeModifier = when (card.size) {
        CardSize.SMALL -> Modifier.height(168.dp)
        CardSize.MEDIUM -> Modifier.heightIn(min = 132.dp)
        CardSize.LARGE -> Modifier.heightIn(min = 240.dp)
    }
    val onClick: (() -> Unit)? = when (card.type) {
        CardType.UPCOMING_EVENTS -> ({ onNavigate(Routes.EVENTS) })
        CardType.GOAL_PROGRESS -> ({ onNavigate(Routes.GOALS) })
        CardType.QUICK_NOTES -> ({ onNavigate(Routes.NOTES) })
        else -> null
    }
    DotCard(modifier.then(sizeModifier).fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AccentDot()
            DotLabel(card.title.ifBlank { card.type.label })
        }
        Spacer(Modifier.height(12.dp))
        when (card.type) {
            CardType.CLOCK -> ClockContent(card.size, state.use24Hour)
            CardType.BATTERY -> BatteryContent(card.size, state)
            CardType.UPCOMING_EVENTS -> UpcomingContent(card.size, state)
            CardType.GOAL_PROGRESS -> GoalsContent(card.size, state)
            CardType.QUICK_NOTES -> NotesContent(card.size, state, onNavigate)
            CardType.CUSTOM_TEXT -> CustomTextContent(card)
        }
    }
}

// ---- Clock ---------------------------------------------------------------------------------

/** Current time, refreshed once a minute and only while the screen is visible. */
@Composable
fun rememberMinuteClock(): State<LocalDateTime> {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val now = remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                val n = LocalDateTime.now()
                now.value = n
                delay(60_000L - (n.second * 1000L + n.nano / 1_000_000L))
            }
        }
    }
    return now
}

@Composable
private fun ClockContent(size: CardSize, use24Hour: Boolean) {
    val now by rememberMinuteClock()
    val time = now.format(DateTimeFormatter.ofPattern(if (use24Hour) "HH:mm" else "h:mm"))
    DotTextFit(time, Modifier.fillMaxWidth(), maxDotSize = if (size == CardSize.LARGE) 12.dp else 9.dp)
    if (size == CardSize.SMALL) return
    Spacer(Modifier.height(12.dp))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        DotLabel(now.toLocalDate().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())), color = DotTheme.colors.textPrimary)
        if (!use24Hour) DotLabel(now.format(DateTimeFormatter.ofPattern("a", Locale.getDefault())), color = DotTheme.colors.accent)
    }
    if (size == CardSize.LARGE) {
        val day = now.dayOfYear
        val total = now.toLocalDate().lengthOfYear()
        Spacer(Modifier.height(16.dp))
        DotProgressBar(day.toFloat() / total, segments = 36)
        Spacer(Modifier.height(6.dp))
        DotLabel("Day $day of $total")
    }
}

// ---- Battery -------------------------------------------------------------------------------

@Composable
private fun BatteryContent(size: CardSize, state: DashboardUiState) {
    val battery = state.battery
    if (battery == null) {
        DotLabel("Unavailable")
        return
    }
    DotText("${battery.level}%", dotSize = 4.dp)
    Spacer(Modifier.height(12.dp))
    DotProgressBar(battery.level / 100f, segments = 20, color = if (battery.level <= 15 && !battery.isCharging) DotTheme.colors.accent else DotTheme.colors.textPrimary)
    Spacer(Modifier.height(8.dp))
    DotLabel(if (battery.isCharging) "Charging" else "On battery")
    if (size != CardSize.SMALL && battery.temperatureC != null) {
        Spacer(Modifier.height(4.dp))
        DotLabel("Temp ${"%.1f".format(Locale.US, battery.temperatureC)}°C")
    }
}

// ---- Upcoming events -----------------------------------------------------------------------

@Composable
private fun UpcomingContent(size: CardSize, state: DashboardUiState) {
    val limit = when (size) { CardSize.SMALL -> 1; CardSize.MEDIUM -> 3; CardSize.LARGE -> 5 }
    val items = state.upcoming.take(limit)
    if (items.isEmpty()) {
        Text("No upcoming events", style = MaterialTheme.typography.bodyMedium, color = DotTheme.colors.textSecondary)
        return
    }
    if (size == CardSize.SMALL) {
        val u = items.first()
        DotText(daysShort(u.daysRemaining), dotSize = 3.dp)
        Spacer(Modifier.height(10.dp))
        Text(u.event.title, style = MaterialTheme.typography.titleMedium, color = DotTheme.colors.textPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis)
        DotLabel(u.date.formatDayMonth())
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        items.forEach { u ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(u.event.title, style = MaterialTheme.typography.titleMedium, color = DotTheme.colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    DotLabel("${u.date.formatDayMonth()} · ${daysLabel(u.daysRemaining)}")
                }
                Spacer(Modifier.width(12.dp))
                DotText(daysShort(u.daysRemaining), dotSize = 3.dp, color = if (u.daysRemaining <= 1) DotTheme.colors.accent else DotTheme.colors.textPrimary)
            }
        }
    }
}

// ---- Goals ---------------------------------------------------------------------------------

@Composable
private fun GoalsContent(size: CardSize, state: DashboardUiState) {
    val goals = state.goals
    if (goals == null || goals.total == 0) {
        Text("Add a daily goal to start tracking", style = MaterialTheme.typography.bodyMedium, color = DotTheme.colors.textSecondary)
        return
    }
    DotText("${goals.percentToday}%", dotSize = if (size == CardSize.SMALL) 4.dp else 5.dp)
    Spacer(Modifier.height(12.dp))
    DotProgressBar(goals.fractionToday, segments = 20)
    Spacer(Modifier.height(8.dp))
    DotLabel("${goals.completedToday}/${goals.total} done")
    if (size != CardSize.SMALL) {
        Spacer(Modifier.height(4.dp))
        DotLabel("Streak ${goals.currentStreak} day${if (goals.currentStreak == 1) "" else "s"} · best ${goals.bestStreak}")
    }
}

// ---- Notes ---------------------------------------------------------------------------------

@Composable
private fun NotesContent(size: CardSize, state: DashboardUiState, onNavigate: (String) -> Unit) {
    val limit = when (size) { CardSize.SMALL -> 1; CardSize.MEDIUM -> 2; CardSize.LARGE -> 4 }
    val items = state.notes.take(limit)
    if (items.isEmpty()) {
        Text("No notes yet", style = MaterialTheme.typography.bodyMedium, color = DotTheme.colors.textSecondary)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.forEach { note ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.small)
                    .clickable { onNavigate(Routes.note(note.id)) },
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(Modifier.padding(top = 5.dp).size(8.dp).clip(CircleShape).background(Color(note.color.argb)))
                Column {
                    Text(note.displayTitle, style = MaterialTheme.typography.titleMedium, color = DotTheme.colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val preview = note.content.takeIf { note.title.isNotBlank() }.orEmpty()
                    if (preview.isNotBlank() && size != CardSize.SMALL) {
                        Text(preview, style = MaterialTheme.typography.bodySmall, color = DotTheme.colors.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

// ---- Custom text ---------------------------------------------------------------------------

@Composable
private fun CustomTextContent(card: DashboardCard) {
    val lines = when (card.size) { CardSize.SMALL -> 4; CardSize.MEDIUM -> 6; CardSize.LARGE -> 12 }
    if (card.content.isBlank()) {
        Text("Edit this card to add text", style = MaterialTheme.typography.bodyMedium, color = DotTheme.colors.textSecondary)
    } else {
        Text(card.content, style = MaterialTheme.typography.bodyMedium, color = DotTheme.colors.textPrimary, maxLines = lines, overflow = TextOverflow.Ellipsis)
    }
}
