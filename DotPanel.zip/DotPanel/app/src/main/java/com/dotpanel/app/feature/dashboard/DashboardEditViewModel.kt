package com.dotpanel.app.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.domain.model.CardSize
import com.dotpanel.app.domain.model.CardType
import com.dotpanel.app.domain.model.DashboardCard
import com.dotpanel.app.domain.model.DashboardPreset
import com.dotpanel.app.domain.repository.DashboardRepository
import com.dotpanel.app.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardEditState(
    val presets: List<DashboardPreset> = emptyList(),
    val active: DashboardPreset? = null,
    /** All cards of the active preset, including hidden ones, in display order. */
    val cards: List<DashboardCard> = emptyList(),
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class DashboardEditViewModel @Inject constructor(
    private val repo: DashboardRepository,
    private val settings: SettingsRepository,
) : ViewModel() {

    private val layout = combine(
        repo.observePresets(),
        settings.settings.map { it.activePresetId }.distinctUntilChanged(),
    ) { presets, activeId -> presets to (presets.firstOrNull { it.id == activeId } ?: presets.firstOrNull()) }

    val state: StateFlow<DashboardEditState> = combine(
        layout,
        layout.flatMapLatest { (_, active) -> if (active == null) flowOf(emptyList()) else repo.observeCards(active.id) },
    ) { (presets, active), cards -> DashboardEditState(presets, active, cards) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardEditState())

    fun selectPreset(id: Long) = viewModelScope.launch { settings.setActivePresetId(id) }

    fun createPreset(name: String, withDefaults: Boolean) = viewModelScope.launch {
        settings.setActivePresetId(repo.createPreset(name, withDefaults))
    }

    fun renamePreset(id: Long, name: String) = viewModelScope.launch { repo.renamePreset(id, name) }

    fun deleteActivePreset() = viewModelScope.launch {
        val s = state.value
        val active = s.active ?: return@launch
        if (s.presets.size <= 1) return@launch
        val next = s.presets.first { it.id != active.id }
        settings.setActivePresetId(next.id)
        repo.deletePreset(active.id)
    }

    fun addCard(type: CardType, title: String, content: String, size: CardSize) = viewModelScope.launch {
        val preset = state.value.active ?: return@launch
        repo.addCard(
            DashboardCard(
                presetId = preset.id,
                type = type,
                title = title.trim().take(100).ifBlank { type.label },
                content = content.take(5_000),
                size = size,
            ),
        )
    }

    fun updateCard(card: DashboardCard) = viewModelScope.launch { repo.updateCard(card) }

    fun deleteCard(id: Long) = viewModelScope.launch { repo.deleteCard(id) }

    fun saveOrder(orderedIds: List<Long>) = viewModelScope.launch { repo.saveOrder(orderedIds) }
}
