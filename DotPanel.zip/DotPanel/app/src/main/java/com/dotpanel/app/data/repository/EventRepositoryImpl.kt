package com.dotpanel.app.data.repository

import com.dotpanel.app.data.toDomain
import com.dotpanel.app.data.toEntity
import com.dotpanel.app.database.EventDao
import com.dotpanel.app.domain.model.Event
import com.dotpanel.app.domain.repository.EventRepository
import com.dotpanel.app.domain.repository.ReminderScheduler
import com.dotpanel.app.domain.repository.WidgetRefresher
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Singleton
class EventRepositoryImpl @Inject constructor(
    private val dao: EventDao,
    private val scheduler: ReminderScheduler,
    private val widgets: WidgetRefresher,
) : EventRepository {

    override fun observeEvents(): Flow<List<Event>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun getEvent(id: Long): Event? = dao.get(id)?.toDomain()

    override suspend fun getEvents(): List<Event> = dao.getAll().map { it.toDomain() }

    override suspend fun upsert(event: Event): Long {
        val clean = event.copy(title = event.title.trim().take(120), notes = event.notes.trim().take(2000))
        val result = dao.upsert(clean.toEntity())
        val id = if (result == -1L) clean.id else result // @Upsert returns -1 for updates
        scheduler.scheduleEvent(clean.copy(id = id))
        widgets.requestRefresh()
        return id
    }

    override suspend fun delete(id: Long) {
        dao.delete(id)
        scheduler.cancelEvent(id)
        widgets.requestRefresh()
    }
}
