package com.dotpanel.app.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.dotpanel.app.domain.model.ThemeMode

/** DotPanel's own palette. Material's colour scheme is derived from it, never the other way round. */
@Immutable
data class DotColors(
    val background: Color,
    val surface: Color,
    val card: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val border: Color,
    val isDark: Boolean,
)

val DarkDotColors = DotColors(
    background = Color(0xFF080808),
    surface = Color(0xFF141414),
    card = Color(0xFF1D1D1D),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFF999999),
    accent = Color(0xFFE51B23),
    border = Color(0xFF303030),
    isDark = true,
)

val LightDotColors = DotColors(
    background = Color(0xFFF4F4F4),
    surface = Color(0xFFEAEAEA),
    card = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF0A0A0A),
    textSecondary = Color(0xFF6B6B6B),
    accent = Color(0xFFE51B23),
    border = Color(0xFFD2D2D2),
    isDark = false,
)

val LocalDotColors = staticCompositionLocalOf { DarkDotColors }

object DotTheme {
    val colors: DotColors
        @Composable @ReadOnlyComposable get() = LocalDotColors.current
}

@Composable
@ReadOnlyComposable
fun ThemeMode.resolveDark(): Boolean = when (this) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

@Composable
fun DotPanelTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = themeMode.resolveDark()
    val c = if (dark) DarkDotColors else LightDotColors
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = Color.White,
            background = c.background, onBackground = c.textPrimary,
            surface = c.card, onSurface = c.textPrimary,
            surfaceVariant = c.surface, onSurfaceVariant = c.textSecondary,
            outline = c.border, outlineVariant = c.border,
            surfaceContainer = c.card, surfaceContainerHigh = c.card, surfaceContainerHighest = c.card,
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = Color.White,
            background = c.background, onBackground = c.textPrimary,
            surface = c.card, onSurface = c.textPrimary,
            surfaceVariant = c.surface, onSurfaceVariant = c.textSecondary,
            outline = c.border, outlineVariant = c.border,
            surfaceContainer = c.card, surfaceContainerHigh = c.card, surfaceContainerHighest = c.card,
        )
    }
    CompositionLocalProvider(LocalDotColors provides c) {
        MaterialTheme(colorScheme = scheme, typography = DotTypography, content = content)
    }
}
