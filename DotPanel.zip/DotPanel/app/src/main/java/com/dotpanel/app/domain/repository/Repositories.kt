package com.dotpanel.app.domain.repository

import com.dotpanel.app.domain.model.AppSettings
import com.dotpanel.app.domain.model.DashboardCard
import com.dotpanel.app.domain.model.DashboardPreset
import com.dotpanel.app.domain.model.Event
import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.model.GoalCompletion
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.ThemeMode
import com.dotpanel.app.domain.model.WidgetConfig
import kotlinx.coroutines.flow.Flow

interface DashboardRepository {
    fun observePresets(): Flow<List<DashboardPreset>>
    fun observeCards(presetId: Long): Flow<List<DashboardCard>>

    /** Creates the default "Home" preset on first launch. Safe to call repeatedly. */
    suspend fun ensureDefaults()
    suspend fun createPreset(name: String, withDefaultCards: Boolean): Long
    suspend fun renamePreset(id: Long, name: String)
    suspend fun deletePreset(id: Long)

    suspend fun addCard(card: DashboardCard): Long
    suspend fun updateCard(card: DashboardCard)
    suspend fun deleteCard(id: Long)
    suspend fun saveOrder(orderedCardIds: List<Long>)
}

interface EventRepository {
    fun observeEvents(): Flow<List<Event>>
    suspend fun getEvent(id: Long): Event?
    suspend fun getEvents(): List<Event>
    suspend fun upsert(event: Event): Long
    suspend fun delete(id: Long)
}

interface NoteRepository {
    fun observeNotes(): Flow<List<Note>>
    suspend fun getNote(id: Long): Note?
    suspend fun getNotes(): List<Note>
    suspend fun upsert(note: Note): Long
    suspend fun delete(id: Long)
}

interface GoalRepository {
    fun observeGoals(): Flow<List<Goal>>
    fun observeCompletions(): Flow<List<GoalCompletion>>
    suspend fun getGoals(): List<Goal>
    suspend fun getCompletions(): List<GoalCompletion>
    suspend fun addGoal(title: String): Long

    /** Removing a goal archives it: its completion history is preserved. */
    suspend fun removeGoal(id: Long)
    suspend fun setCompleted(goalId: Long, epochDay: Long, completed: Boolean)
}

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setUse24HourClock(value: Boolean)
    suspend fun setActivePresetId(id: Long)
    suspend fun setEventReminderHour(hour: Int)
    suspend fun setGoalReminderEnabled(enabled: Boolean)
    suspend fun setGoalReminderHour(hour: Int)
}

interface WidgetConfigRepository {
    suspend fun get(appWidgetId: Int): WidgetConfig?
    suspend fun save(config: WidgetConfig)
    suspend fun delete(appWidgetIds: List<Int>)
}

data class BackupSummary(val presets: Int, val cards: Int, val events: Int, val notes: Int, val goals: Int)

interface BackupRepository {
    /** [uri] is a content:// URI string chosen through the Storage Access Framework. */
    suspend fun export(uri: String): Result<BackupSummary>
    suspend fun import(uri: String): Result<BackupSummary>
}

/** Schedules deferrable background reminders. Implemented with WorkManager (no exact alarms). */
interface ReminderScheduler {
    suspend fun scheduleEvent(event: Event)
    fun cancelEvent(eventId: Long)
    suspend fun syncGoalReminder()
    suspend fun rescheduleAll()
}

/** Asks the home-screen widgets to redraw. Debounced, so it is cheap to call after every write. */
interface WidgetRefresher {
    fun requestRefresh()
}
