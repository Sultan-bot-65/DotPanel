package com.dotpanel.app.feature.goals

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.core.util.formatDayMonth
import com.dotpanel.app.designsystem.DotButton
import com.dotpanel.app.designsystem.DotCard
import com.dotpanel.app.designsystem.DotDialog
import com.dotpanel.app.designsystem.DotIconButton
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotProgressBar
import com.dotpanel.app.designsystem.DotText
import com.dotpanel.app.designsystem.DotTextField
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.EmptyState
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.domain.model.DayProgress
import com.dotpanel.app.domain.model.GoalStats

@Composable
fun GoalsScreen(
    modifier: Modifier = Modifier,
    viewModel: GoalsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var draft by rememberSaveable { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<GoalItem?>(null) }

    fun submit() {
        viewModel.addGoal(draft)
        draft = ""
    }

    Column(modifier.fillMaxSize().statusBarsPadding()) {
        ScreenHeader(title = "Goals", subtitle = state.today.formatDayMonth())

        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            state.stats?.let { stats ->
                item(key = "progress") { ProgressCard(stats) }
            }

            item(key = "add") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { DotTextField(draft, { draft = it.take(120) }, "New goal") }
                    DotIconButton(Icons.Outlined.Add, "Add goal", ::submit, filled = true)
                }
            }

            if (!state.loading && state.items.isEmpty()) {
                item(key = "empty") {
                    EmptyState("No goals yet.", hint = "Add one above to start a streak")
                }
            }

            items(state.items, key = { it.goal.id }) { item ->
                GoalRow(
                    item = item,
                    onToggle = { viewModel.toggle(item) },
                    onDelete = { pendingDelete = item },
                )
            }
        }
    }

    pendingDelete?.let { target ->
        DotDialog(
            title = "Remove goal",
            onDismiss = { pendingDelete = null },
            confirmText = "Remove",
            onConfirm = {
                viewModel.remove(target.goal.id)
                pendingDelete = null
            },
        ) {
            Text(
                "“${target.goal.title}” will disappear from your list. Your past completions are kept.",
                style = MaterialTheme.typography.bodyMedium,
                color = DotTheme.colors.textSecondary,
            )
        }
    }
}

@Composable
private fun ProgressCard(stats: GoalStats) {
    val colors = DotTheme.colors
    DotCard(Modifier.fillMaxWidth()) {
        DotLabel("Today")
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            DotText("${stats.percentToday}%", dotSize = 6.dp, gap = 2.dp)
            Spacer(Modifier.weight(1f))
            Text(
                "${stats.completedToday} / ${stats.total}",
                style = MaterialTheme.typography.titleMedium,
                color = colors.textSecondary,
            )
        }
        Spacer(Modifier.height(16.dp))
        DotProgressBar(stats.fractionToday)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            Column {
                DotLabel("Streak")
                Spacer(Modifier.height(4.dp))
                Text(daysText(stats.currentStreak), style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
            }
            Column {
                DotLabel("Best")
                Spacer(Modifier.height(4.dp))
                Text(daysText(stats.bestStreak), style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
            }
        }
        Spacer(Modifier.height(20.dp))
        DotLabel("Last ${stats.history.size} days")
        Spacer(Modifier.height(8.dp))
        HistoryStrip(stats.history)
    }
}

private fun daysText(n: Int) = if (n == 1) "1 day" else "$n days"

/** One dot per day: red = every goal done, outlined = partial, faint = nothing / no goals yet. */
@Composable
private fun HistoryStrip(history: List<DayProgress>) {
    val colors = DotTheme.colors
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        history.forEach { day ->
            val complete = day.total > 0 && day.completed == day.total
            val partial = day.completed in 1 until day.total
            val description = "${day.date.formatDayMonth()}: ${day.completed} of ${day.total} goals"
            Box(
                Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(if (complete) colors.accent else Color.Transparent)
                    .border(1.dp, if (complete) colors.accent else if (partial) colors.textSecondary else colors.border, CircleShape)
                    .semantics { contentDescription = description },
            )
        }
    }
}

@Composable
private fun GoalRow(item: GoalItem, onToggle: () -> Unit, onDelete: () -> Unit) {
    val colors = DotTheme.colors
    DotCard(Modifier.fillMaxWidth(), padding = 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Checkbox, onClick = onToggle)
                    .semantics { contentDescription = if (item.done) "Mark ${item.goal.title} not done" else "Mark ${item.goal.title} done" },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(if (item.done) colors.accent else Color.Transparent)
                        .border(1.5.dp, if (item.done) colors.accent else colors.textSecondary, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (item.done) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White))
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            Text(
                item.goal.title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyLarge,
                color = if (item.done) colors.textSecondary else colors.textPrimary,
                textDecoration = if (item.done) TextDecoration.LineThrough else null,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            DotIconButton(Icons.Outlined.Delete, "Remove ${item.goal.title}", onDelete, tint = colors.textSecondary)
        }
    }
}
