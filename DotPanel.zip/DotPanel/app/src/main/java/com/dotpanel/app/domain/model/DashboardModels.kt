package com.dotpanel.app.domain.model

enum class CardType(val label: String) {
    CLOCK("Clock & Date"),
    BATTERY("Battery"),
    UPCOMING_EVENTS("Upcoming Events"),
    GOAL_PROGRESS("Daily Goals"),
    QUICK_NOTES("Quick Notes"),
    CUSTOM_TEXT("Custom Text"),
}

enum class CardSize(val label: String, val short: String) {
    SMALL("Small", "S"),
    MEDIUM("Medium", "M"),
    LARGE("Large", "L"),
}

data class DashboardPreset(val id: Long, val name: String)

data class DashboardCard(
    val id: Long = 0,
    val presetId: Long,
    val type: CardType,
    val title: String,
    val content: String = "",
    val size: CardSize = CardSize.MEDIUM,
    val position: Int = 0,
    val visible: Boolean = true,
)

/** Cards created for the first preset and for presets created "with defaults". */
object DefaultDashboard {
    fun cards(presetId: Long): List<DashboardCard> = listOf(
        DashboardCard(presetId = presetId, type = CardType.CLOCK, title = "Now", size = CardSize.LARGE, position = 0),
        DashboardCard(presetId = presetId, type = CardType.GOAL_PROGRESS, title = "Today", size = CardSize.SMALL, position = 1),
        DashboardCard(presetId = presetId, type = CardType.BATTERY, title = "Battery", size = CardSize.SMALL, position = 2),
        DashboardCard(presetId = presetId, type = CardType.UPCOMING_EVENTS, title = "Upcoming", size = CardSize.MEDIUM, position = 3),
        DashboardCard(presetId = presetId, type = CardType.QUICK_NOTES, title = "Notes", size = CardSize.MEDIUM, position = 4),
    )
}
