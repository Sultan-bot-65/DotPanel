package com.dotpanel.app.widgets.config

import android.content.Context
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.model.AppSettings
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.ThemeMode
import com.dotpanel.app.domain.model.UpcomingEvent
import com.dotpanel.app.domain.model.WidgetConfig
import com.dotpanel.app.domain.model.WidgetType
import com.dotpanel.app.domain.repository.EventRepository
import com.dotpanel.app.domain.repository.NoteRepository
import com.dotpanel.app.domain.repository.SettingsRepository
import com.dotpanel.app.domain.repository.WidgetConfigRepository
import com.dotpanel.app.widgets.ClockWidget
import com.dotpanel.app.widgets.CountdownWidget
import com.dotpanel.app.widgets.GoalsWidget
import com.dotpanel.app.widgets.NotesWidget
import com.dotpanel.app.widgets.SummaryWidget
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class WidgetConfigUiState(
    val loading: Boolean = true,
    val type: WidgetType? = null,
    val config: WidgetConfig? = null,
    val events: List<UpcomingEvent> = emptyList(),
    val notes: List<Note> = emptyList(),
)

@HiltViewModel
class WidgetConfigViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val configs: WidgetConfigRepository,
    private val events: EventRepository,
    private val notes: NoteRepository,
    private val settings: SettingsRepository,
    private val dateProvider: DateProvider,
) : ViewModel() {

    private val _state = MutableStateFlow(WidgetConfigUiState())
    val state: StateFlow<WidgetConfigUiState> = _state.asStateFlow()

    val themeMode: StateFlow<ThemeMode> = settings.settings
        .map { it.themeMode }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings().themeMode)

    private var loadedFor: Int? = null

    /** Loads the widget's saved settings (or sensible defaults) plus the lists the pickers need. */
    fun load(appWidgetId: Int, type: WidgetType) {
        if (loadedFor == appWidgetId) return
        loadedFor = appWidgetId
        viewModelScope.launch {
            val today = dateProvider.today()
            val saved = configs.get(appWidgetId)
            val default = WidgetConfig(
                appWidgetId = appWidgetId,
                type = type,
                use24Hour = settings.settings.first().use24HourClock,
            )
            _state.value = WidgetConfigUiState(
                loading = false,
                type = type,
                // A saved row for a different provider (should not happen) is ignored.
                config = saved?.takeIf { it.type == type } ?: default,
                events = events.getEvents().map { it.toUpcoming(today) }.sortedBy { if (it.passed) Long.MAX_VALUE else it.daysRemaining },
                notes = notes.getNotes().filter { !it.isBlank }.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updatedAt }),
            )
        }
    }

    fun edit(transform: (WidgetConfig) -> WidgetConfig) {
        _state.update { s -> s.copy(config = s.config?.let(transform)) }
    }

    /** Saves the settings, then redraws this one widget so the choice shows immediately. */
    suspend fun save() {
        val config = _state.value.config ?: return
        configs.save(config)
        try {
            val glanceId = GlanceAppWidgetManager(context).getGlanceIdBy(config.appWidgetId)
            widgetFor(config.type).update(context, glanceId)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Not fatal: the system sends an update as soon as the configuration screen closes.
        }
    }

    private fun widgetFor(type: WidgetType): GlanceAppWidget = when (type) {
        WidgetType.CLOCK -> ClockWidget()
        WidgetType.COUNTDOWN -> CountdownWidget()
        WidgetType.GOALS -> GoalsWidget()
        WidgetType.NOTES -> NotesWidget()
        WidgetType.SUMMARY -> SummaryWidget()
    }
}
