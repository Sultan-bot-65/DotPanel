package com.dotpanel.app.core.di

import javax.inject.Qualifier

/** Long-lived scope for work that must outlive a screen (final note save, widget refresh). */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ApplicationScope
