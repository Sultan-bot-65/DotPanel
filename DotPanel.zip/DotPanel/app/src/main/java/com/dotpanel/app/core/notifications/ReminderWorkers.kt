package com.dotpanel.app.core.notifications

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.repository.EventRepository
import com.dotpanel.app.domain.repository.GoalRepository
import com.dotpanel.app.domain.repository.ReminderScheduler
import com.dotpanel.app.domain.repository.SettingsRepository
import com.dotpanel.app.domain.usecase.GoalStatsCalculator
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

/** Fires one event/countdown reminder, then re-arms the next one (recurring events, other offsets). */
@HiltWorker
class EventReminderWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val events: EventRepository,
    private val scheduler: ReminderScheduler,
    private val notifications: NotificationHelper,
    private val dateProvider: DateProvider,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val id = inputData.getLong(KEY_EVENT_ID, -1L)
        val event = events.getEvent(id) ?: return Result.success() // deleted meanwhile
        val days = event.daysRemaining(dateProvider.today())
        // Only notify when today really is one of the chosen offsets (guards against late runs).
        if (days.toInt() in event.reminderOffsets && days >= 0) {
            notifications.notifyEvent(event, days)
        }
        scheduler.scheduleEvent(event)
        return Result.success()
    }

    companion object {
        const val KEY_EVENT_ID = "event_id"
    }
}

/** Evening nudge listing unfinished goals; only when enabled in settings. */
@HiltWorker
class GoalReminderWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val goals: GoalRepository,
    private val settings: SettingsRepository,
    private val scheduler: ReminderScheduler,
    private val notifications: NotificationHelper,
    private val dateProvider: DateProvider,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!settings.settings.first().goalReminderEnabled) return Result.success()
        val stats = GoalStatsCalculator.calculate(
            goals.getGoals(),
            goals.getCompletions(),
            dateProvider.today(),
            historyDays = 1,
        )
        val remaining = stats.total - stats.completedToday
        if (stats.total > 0 && remaining > 0) notifications.notifyGoals(remaining, stats.total)
        scheduler.syncGoalReminder()
        return Result.success()
    }
}
