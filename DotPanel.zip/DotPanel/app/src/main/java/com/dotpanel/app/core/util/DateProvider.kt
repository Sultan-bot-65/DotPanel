package com.dotpanel.app.core.util

import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow

/** Single source of "today" so the UI, use cases and tests agree on the current date. */
@Singleton
class DateProvider @Inject constructor() {
    fun today(): LocalDate = LocalDate.now()

    /** Emits today's date immediately and again just after every local midnight. */
    val todayFlow: Flow<LocalDate> = flow {
        while (true) {
            val now = LocalDateTime.now()
            emit(now.toLocalDate())
            val nextMidnight = now.toLocalDate().plusDays(1).atStartOfDay()
            delay(Duration.between(now, nextMidnight).toMillis() + 500)
        }
    }.distinctUntilChanged()
}
