package com.dotpanel.app.data.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.dotpanel.app.database.DashboardDao
import com.dotpanel.app.database.DotPanelDatabase
import com.dotpanel.app.database.EventDao
import com.dotpanel.app.database.GoalDao
import com.dotpanel.app.database.NoteDao
import com.dotpanel.app.domain.repository.BackupRepository
import com.dotpanel.app.domain.repository.BackupSummary
import com.dotpanel.app.domain.repository.ReminderScheduler
import com.dotpanel.app.domain.repository.SettingsRepository
import com.dotpanel.app.domain.repository.WidgetRefresher
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.IOException
import java.io.InputStream
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Singleton
class BackupRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val db: DotPanelDatabase,
    private val dashboardDao: DashboardDao,
    private val eventDao: EventDao,
    private val noteDao: NoteDao,
    private val goalDao: GoalDao,
    private val settings: SettingsRepository,
    private val scheduler: ReminderScheduler,
    private val widgets: WidgetRefresher,
) : BackupRepository {

    override suspend fun export(uri: String): Result<BackupSummary> = withContext(Dispatchers.IO) {
        runCatching {
            // Read everything in one transaction so the file is a consistent snapshot.
            val file = db.withTransaction {
                BackupFile(
                    exportedAt = System.currentTimeMillis(),
                    presets = dashboardDao.getPresets(),
                    cards = dashboardDao.getCards(),
                    events = eventDao.getAll(),
                    notes = noteDao.getAll(),
                    goals = goalDao.getAll(),
                    completions = goalDao.getCompletions(),
                )
            }
            val text = BackupCodec.encode(file)
            val out = context.contentResolver.openOutputStream(Uri.parse(uri), "wt")
                ?: throw IOException("Could not open the destination file.")
            out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            file.summary()
        }
    }

    override suspend fun import(uri: String): Result<BackupSummary> = withContext(Dispatchers.IO) {
        runCatching {
            val input = context.contentResolver.openInputStream(Uri.parse(uri))
                ?: throw IOException("Could not open the selected file.")
            val text = input.use { readLimited(it) }
            val file = BackupCodec.decode(text) // throws BackupException before any data is touched

            db.withTransaction {
                // Deleting presets cascades to cards; deleting goals cascades to completions.
                dashboardDao.clearPresets()
                eventDao.clear()
                noteDao.clear()
                goalDao.clearGoals()

                dashboardDao.restorePresets(file.presets)
                dashboardDao.restoreCards(file.cards)
                eventDao.restore(file.events)
                noteDao.restore(file.notes)
                goalDao.restoreGoals(file.goals)
                goalDao.restoreCompletions(file.completions)
            }
            settings.setActivePresetId(file.presets.first().id)
            scheduler.rescheduleAll()
            widgets.requestRefresh()
            file.summary()
        }
    }

    private fun readLimited(input: InputStream): String {
        val buffer = java.io.ByteArrayOutputStream()
        val chunk = ByteArray(16 * 1024)
        while (true) {
            val read = input.read(chunk)
            if (read < 0) break
            buffer.write(chunk, 0, read)
            if (buffer.size() > BackupCodec.MAX_BYTES) throw BackupException("The backup file is too large.")
        }
        return buffer.toString(Charsets.UTF_8.name())
    }

    private fun BackupFile.summary() = BackupSummary(presets.size, cards.size, events.size, notes.size, goals.size)
}
