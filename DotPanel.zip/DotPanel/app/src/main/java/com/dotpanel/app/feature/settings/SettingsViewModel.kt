package com.dotpanel.app.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.data.backup.BackupException
import com.dotpanel.app.domain.model.AppSettings
import com.dotpanel.app.domain.model.ThemeMode
import com.dotpanel.app.domain.repository.BackupRepository
import com.dotpanel.app.domain.repository.BackupSummary
import com.dotpanel.app.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val busy: Boolean = false,
    /** Result text of the last export/import; cleared when the next one starts. */
    val message: String? = null,
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val backup: BackupRepository,
) : ViewModel() {

    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    val uiState: StateFlow<SettingsUiState> =
        combine(settingsRepository.settings, busy, message) { settings, isBusy, text ->
            SettingsUiState(settings, isBusy, text)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun setThemeMode(mode: ThemeMode) = launch { settingsRepository.setThemeMode(mode) }
    fun setUse24HourClock(value: Boolean) = launch { settingsRepository.setUse24HourClock(value) }
    fun setEventReminderHour(hour: Int) = launch { settingsRepository.setEventReminderHour(hour) }
    fun setGoalReminderEnabled(enabled: Boolean) = launch { settingsRepository.setGoalReminderEnabled(enabled) }
    fun setGoalReminderHour(hour: Int) = launch { settingsRepository.setGoalReminderHour(hour) }

    fun export(uri: String) = runBackup("Exported") { backup.export(uri) }

    /** Replaces all current data with the file's contents; the screen asks for confirmation first. */
    fun import(uri: String) = runBackup("Restored") { backup.import(uri) }

    private fun runBackup(verb: String, block: suspend () -> Result<BackupSummary>) {
        if (busy.value) return
        busy.value = true
        message.value = null
        viewModelScope.launch {
            val result = block()
            message.update {
                result.fold(
                    onSuccess = { it.describe(verb) },
                    onFailure = { error ->
                        // BackupException messages are written for people; anything else is generic.
                        if (error is BackupException) error.message ?: GENERIC_FAILURE else GENERIC_FAILURE
                    },
                )
            }
            busy.value = false
        }
    }

    private fun launch(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }

    private fun BackupSummary.describe(verb: String): String =
        "$verb $presets layouts, $cards cards, $events events, $notes notes and $goals goals."

    private companion object {
        const val GENERIC_FAILURE = "That didn't work. Check the file and try again."
    }
}
