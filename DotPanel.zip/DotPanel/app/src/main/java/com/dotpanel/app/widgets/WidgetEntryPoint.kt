package com.dotpanel.app.widgets

import android.content.Context
import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.repository.EventRepository
import com.dotpanel.app.domain.repository.GoalRepository
import com.dotpanel.app.domain.repository.NoteRepository
import com.dotpanel.app.domain.repository.WidgetConfigRepository
import com.dotpanel.app.domain.repository.WidgetRefresher
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent

/**
 * Glance widgets and broadcast receivers are instantiated by the system, not by Hilt, so they reach
 * the object graph through this entry point instead of constructor injection.
 */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface WidgetEntryPoint {
    fun events(): EventRepository
    fun notes(): NoteRepository
    fun goals(): GoalRepository
    fun widgetConfigs(): WidgetConfigRepository
    fun dateProvider(): DateProvider
    fun refresher(): WidgetRefresher
}

internal fun Context.widgetEntryPoint(): WidgetEntryPoint =
    EntryPointAccessors.fromApplication(applicationContext, WidgetEntryPoint::class.java)
