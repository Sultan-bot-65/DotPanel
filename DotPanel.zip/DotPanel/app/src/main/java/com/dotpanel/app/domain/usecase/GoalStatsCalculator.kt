package com.dotpanel.app.domain.usecase

import com.dotpanel.app.domain.model.DayProgress
import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.model.GoalCompletion
import com.dotpanel.app.domain.model.GoalStats
import java.time.LocalDate

/**
 * Pure goal maths (no Android, no I/O) so it is trivially unit-testable.
 *
 * A day is "complete" when at least one goal existed on that day and every goal that existed on
 * that day was ticked. Today does not break a streak until it has ended without being completed.
 */
object GoalStatsCalculator {

    fun calculate(
        goals: List<Goal>,
        completions: List<GoalCompletion>,
        today: LocalDate,
        historyDays: Int = 14,
    ): GoalStats {
        val todayEpoch = today.toEpochDay()
        val doneByDay: Map<Long, Set<Long>> = completions
            .groupBy({ it.epochDay }, { it.goalId })
            .mapValues { it.value.toSet() }

        fun applicable(day: Long): List<Goal> = goals.filter { it.createdEpochDay <= day }

        fun progress(day: Long): Pair<Int, Int> {
            val list = applicable(day)
            val done = doneByDay[day].orEmpty()
            return list.count { it.id in done } to list.size
        }

        fun isComplete(day: Long): Boolean {
            val (done, total) = progress(day)
            return total > 0 && done == total
        }

        val earliest = goals.minOfOrNull { it.createdEpochDay }
        var current = 0
        var best = 0
        if (earliest != null) {
            var day = if (isComplete(todayEpoch)) todayEpoch else todayEpoch - 1
            while (day >= earliest && isComplete(day)) {
                current++
                day--
            }
            var run = 0
            for (d in earliest..todayEpoch) {
                if (isComplete(d)) {
                    run++
                    if (run > best) best = run
                } else {
                    run = 0
                }
            }
        }

        val history = (historyDays - 1 downTo 0).map { offset ->
            val day = todayEpoch - offset
            val (done, total) = progress(day)
            DayProgress(LocalDate.ofEpochDay(day), done, total)
        }
        val (doneToday, totalToday) = progress(todayEpoch)
        return GoalStats(
            total = goals.size.coerceAtLeast(totalToday),
            completedToday = doneToday,
            currentStreak = current,
            bestStreak = best,
            history = history,
        )
    }
}
