package com.dotpanel.app.core.notifications

import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.dotpanel.app.database.EventDao
import com.dotpanel.app.data.toDomain
import com.dotpanel.app.domain.model.Event
import com.dotpanel.app.domain.repository.ReminderScheduler
import com.dotpanel.app.domain.repository.SettingsRepository
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

/**
 * Schedules reminders with WorkManager one-shot work, re-armed after each firing.
 *
 * Why not AlarmManager.setExact*? An event reminder only needs to land "around 9:00", not at
 * 09:00:00, so deferrable work is enough. That avoids the SCHEDULE_EXACT_ALARM / USE_EXACT_ALARM
 * permissions entirely, survives reboots, and respects Doze and battery optimisations.
 */
@Singleton
class WorkReminderScheduler @Inject constructor(
    private val workManager: WorkManager,
    private val settings: SettingsRepository,
    private val eventDao: EventDao,
) : ReminderScheduler {

    override suspend fun scheduleEvent(event: Event) {
        val hour = settings.settings.first().eventReminderHour
        val now = LocalDateTime.now()
        val trigger = event.nextReminderTrigger(now, hour)
        if (trigger == null) {
            cancelEvent(event.id)
            return
        }
        val delayMs = Duration.between(now, trigger).toMillis().coerceAtLeast(0)
        val request = OneTimeWorkRequestBuilder<EventReminderWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(EventReminderWorker.KEY_EVENT_ID to event.id))
            .build()
        workManager.enqueueUniqueWork(eventWorkName(event.id), ExistingWorkPolicy.REPLACE, request)
    }

    override fun cancelEvent(eventId: Long) {
        workManager.cancelUniqueWork(eventWorkName(eventId))
    }

    override suspend fun syncGoalReminder() {
        val s = settings.settings.first()
        if (!s.goalReminderEnabled) {
            workManager.cancelUniqueWork(GOAL_WORK_NAME)
            return
        }
        val now = LocalDateTime.now()
        var trigger = now.toLocalDate().atTime(s.goalReminderHour, 0)
        if (!trigger.isAfter(now)) trigger = trigger.plusDays(1)
        val request = OneTimeWorkRequestBuilder<GoalReminderWorker>()
            .setInitialDelay(Duration.between(now, trigger).toMillis(), TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniqueWork(GOAL_WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }

    override suspend fun rescheduleAll() {
        eventDao.getAll().map { it.toDomain() }.forEach { scheduleEvent(it) }
        syncGoalReminder()
    }

    private fun eventWorkName(id: Long) = "event_reminder_$id"

    private companion object {
        const val GOAL_WORK_NAME = "goal_reminder"
    }
}
