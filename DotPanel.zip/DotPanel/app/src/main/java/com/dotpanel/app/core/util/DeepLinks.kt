package com.dotpanel.app.core.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.dotpanel.app.MainActivity

private const val SCHEME = "dotpanel"

/**
 * Builds an explicit intent that opens [route] inside the app. The route is carried in the intent
 * data (`dotpanel:note/5`) rather than an extra, because PendingIntent equality ignores extras:
 * two widgets pointing at different routes would otherwise collapse into one PendingIntent.
 */
fun deepLinkIntent(context: Context, route: String): Intent =
    Intent(context, MainActivity::class.java).apply {
        action = Intent.ACTION_VIEW
        data = Uri.fromParts(SCHEME, route, null)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    }

fun Intent.routeOrNull(): String? =
    data?.takeIf { it.scheme == SCHEME }?.schemeSpecificPart?.takeIf { it.isNotBlank() }
