package com.dotpanel.app.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

data class BottomBarItem(val route: String, val label: String, val icon: ImageVector)

/** Flat bottom navigation: icon, caption and a red dot under the selected destination. */
@Composable
fun DotBottomBar(
    items: List<BottomBarItem>,
    selectedRoute: String?,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = DotTheme.colors
    Column(
        modifier
            .fillMaxWidth()
            .background(colors.background)
            .border(width = 0.dp, color = Color.Transparent),
    ) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(colors.border))
        Row(
            Modifier
                .navigationBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
        ) {
            items.forEach { item ->
                val selected = item.route == selectedRoute
                Column(
                    Modifier
                        .weight(1f)
                        .heightIn(min = 60.dp)
                        .semantics {
                            this.selected = selected
                            contentDescription = item.label
                        }
                        .clickable(role = Role.Tab) { onSelect(item.route) }
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(
                        item.icon,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp),
                        tint = if (selected) colors.textPrimary else colors.textSecondary,
                    )
                    Spacer(Modifier.height(4.dp))
                    DotLabel(item.label, color = if (selected) colors.textPrimary else colors.textSecondary)
                    Spacer(Modifier.height(4.dp))
                    AccentDot(size = 4.dp, color = if (selected) colors.accent else Color.Transparent)
                }
            }
        }
    }
}
