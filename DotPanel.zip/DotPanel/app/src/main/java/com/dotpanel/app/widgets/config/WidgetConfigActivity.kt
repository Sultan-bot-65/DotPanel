package com.dotpanel.app.widgets.config

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.dotpanel.app.designsystem.DotPanelTheme
import com.dotpanel.app.domain.model.WidgetType
import com.dotpanel.app.widgets.ClockWidgetReceiver
import com.dotpanel.app.widgets.CountdownWidgetReceiver
import com.dotpanel.app.widgets.GoalsWidgetReceiver
import com.dotpanel.app.widgets.NotesWidgetReceiver
import com.dotpanel.app.widgets.SummaryWidgetReceiver
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

/**
 * Shared configuration screen for all five widgets. Android starts it when a widget is added and,
 * because the widgets are `reconfigurable`, again when the user long-presses one and chooses to
 * reconfigure it. Backing out leaves the widget unplaced / unchanged.
 */
@AndroidEntryPoint
class WidgetConfigActivity : ComponentActivity() {

    private val viewModel: WidgetConfigViewModel by viewModels()
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID,
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        // Until the user confirms, the answer is "cancelled" so a back-press never places the widget.
        setResult(RESULT_CANCELED, resultIntent())

        val type = if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) null else resolveType(appWidgetId)
        if (type == null) {
            finish()
            return
        }
        viewModel.load(appWidgetId, type)

        setContent {
            val theme by viewModel.themeMode.collectAsStateWithLifecycle()
            val state by viewModel.state.collectAsStateWithLifecycle()
            DotPanelTheme(theme) {
                WidgetConfigScreen(
                    state = state,
                    onEdit = viewModel::edit,
                    onCancel = ::finish,
                    onConfirm = ::confirm,
                )
            }
        }
    }

    private fun confirm() {
        lifecycleScope.launch {
            viewModel.save()
            setResult(RESULT_OK, resultIntent())
            finish()
        }
    }

    private fun resultIntent() = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)

    /** The widget's provider class tells us which kind of widget this is. */
    private fun resolveType(id: Int): WidgetType? =
        when (AppWidgetManager.getInstance(this).getAppWidgetInfo(id)?.provider?.className) {
            ClockWidgetReceiver::class.java.name -> WidgetType.CLOCK
            CountdownWidgetReceiver::class.java.name -> WidgetType.COUNTDOWN
            GoalsWidgetReceiver::class.java.name -> WidgetType.GOALS
            NotesWidgetReceiver::class.java.name -> WidgetType.NOTES
            SummaryWidgetReceiver::class.java.name -> WidgetType.SUMMARY
            else -> null
        }
}
