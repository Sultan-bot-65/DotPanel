package com.dotpanel.app.widgets

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.dotpanel.app.designsystem.COLS
import com.dotpanel.app.designsystem.GLYPHS
import com.dotpanel.app.designsystem.ROWS
import kotlin.math.ceil
import kotlin.math.min

/** A rendered bitmap together with the dp size it should be displayed at. */
internal class DotBitmapImage(val bitmap: Bitmap, val width: Dp, val height: Dp)

/**
 * Draws the app's 5x7 dot-matrix typography into bitmaps, because Glance has no Canvas.
 *
 * Bitmaps are drawn white (lit dots opaque, unlit dots faint) and tinted at display time with a
 * day/night colour provider, so one bitmap is correct in both themes.
 */
internal object DotBitmap {

    private const val OFF_ALPHA = 46
    private const val DOT_FRACTION = 0.72f

    /** Largest dot size (dp) at which [text] fits inside [maxWidth] x [maxHeight], capped at [maxDot]. */
    fun fitDot(text: String, maxWidth: Dp, maxHeight: Dp, maxDot: Dp): Float {
        val columns = (text.length * (COLS + 1) - 1).coerceAtLeast(1)
        val pitch = min(
            min(maxWidth.value / columns, maxHeight.value / ROWS),
            maxDot.value / DOT_FRACTION,
        ).coerceAtLeast(1.5f)
        return pitch * DOT_FRACTION
    }

    fun text(context: Context, text: String, dotDp: Float): DotBitmapImage {
        val density = context.resources.displayMetrics.density
        val dot = dotDp * density
        val gap = dot * (1f - DOT_FRACTION) / DOT_FRACTION
        val pitch = dot + gap
        val chars = text.uppercase().ifEmpty { " " }
        val columns = chars.length * (COLS + 1) - 1

        val width = ceil(pitch * columns - gap).toInt().coerceAtLeast(1)
        val height = ceil(pitch * ROWS - gap).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val lit = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val unlit = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(OFF_ALPHA, 255, 255, 255) }
        val radius = dot / 2f

        chars.forEachIndexed { index, ch ->
            val glyph = GLYPHS[ch] ?: GLYPHS.getValue('?')
            for (row in 0 until ROWS) {
                for (col in 0 until COLS) {
                    canvas.drawCircle(
                        (index * (COLS + 1) + col) * pitch + radius,
                        row * pitch + radius,
                        radius,
                        if (glyph[row * COLS + col]) lit else unlit,
                    )
                }
            }
        }
        return DotBitmapImage(bitmap, (width / density).dp, (height / density).dp)
    }

    /** A row of [segments] dots, the first `fraction * segments` of them lit. */
    fun progress(context: Context, fraction: Float, segments: Int, width: Dp, height: Dp): DotBitmapImage {
        val density = context.resources.displayMetrics.density
        val w = (width.value * density).toInt().coerceAtLeast(segments)
        val h = (height.value * density).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val lit = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val unlit = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(OFF_ALPHA, 255, 255, 255) }
        val pitch = w.toFloat() / segments
        val radius = min(pitch * 0.32f, h / 2f)
        val filled = Math.round(fraction.coerceIn(0f, 1f) * segments)
        for (i in 0 until segments) {
            canvas.drawCircle(pitch * i + pitch / 2f, h / 2f, radius, if (i < filled) lit else unlit)
        }
        return DotBitmapImage(bitmap, (w / density).dp, (h / density).dp)
    }
}
