package com.dotpanel.app.widgets

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Short-lived scope for work that must finish inside a broadcast (guarded by goAsync). */
private val receiverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

/** Base for all five widget receivers: removes a widget's saved settings when the user deletes it. */
abstract class DotPanelWidgetReceiver : GlanceAppWidgetReceiver() {

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        val pending = goAsync()
        val ids = appWidgetIds.toList()
        receiverScope.launch {
            try {
                context.widgetEntryPoint().widgetConfigs().delete(ids)
            } finally {
                pending.finish()
            }
        }
    }
}

/**
 * Date, time and time-zone changes make "days remaining" and "today's goals" stale, so they trigger
 * one debounced redraw. These are system broadcasts; the receiver costs nothing while idle.
 */
class WidgetTimeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        context.widgetEntryPoint().refresher().requestRefresh()
    }
}
