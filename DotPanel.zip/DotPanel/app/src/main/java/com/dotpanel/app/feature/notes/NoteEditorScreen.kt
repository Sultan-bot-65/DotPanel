package com.dotpanel.app.feature.notes

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.designsystem.DotDialog
import com.dotpanel.app.designsystem.DotIconButton
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTextField
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.EmptyState
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.domain.model.NoteColor

@Composable
fun NoteEditorScreen(
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: NoteEditorViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf(false) }
    val colors = DotTheme.colors

    // Auto-save guarantees: debounce while typing, then flush on back, on leaving, and on backgrounding.
    BackHandler { viewModel.flush(); onClose() }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { viewModel.flush() }
    DisposableEffect(Unit) { onDispose { viewModel.flush() } }

    Column(modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        ScreenHeader(
            title = "Note",
            subtitle = when (state.status) {
                SaveStatus.SAVING -> "Saving…"
                SaveStatus.SAVED -> "Saved"
                SaveStatus.IDLE -> "Auto-saves as you type"
            },
            navigationIcon = {
                DotIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "Back", { viewModel.flush(); onClose() })
            },
            actions = {
                DotIconButton(
                    icon = if (state.pinned) Icons.Filled.Star else Icons.Outlined.Star,
                    contentDescription = if (state.pinned) "Unpin note" else "Pin note",
                    onClick = viewModel::togglePinned,
                    tint = if (state.pinned) colors.accent else colors.textPrimary,
                )
                DotIconButton(Icons.Outlined.Delete, "Delete note", { confirmDelete = true })
            },
        )

        if (state.notFound) {
            EmptyState("This note no longer exists.")
            return@Column
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                DotLabel("Label")
                NoteColor.entries.forEach { option ->
                    val selected = option == state.color
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(option.toComposeColor())
                            .border(
                                width = if (selected) 2.dp else 1.dp,
                                color = if (selected) colors.textPrimary else colors.border,
                                shape = CircleShape,
                            )
                            .clickable(role = Role.RadioButton) { viewModel.setColor(option) },
                    )
                }
            }
            DotTextField(state.title, viewModel::setTitle, "Title")
            DotTextField(state.content, viewModel::setContent, "Write something…", singleLine = false, minLines = 10)
        }
    }

    if (confirmDelete) {
        DotDialog(
            title = "Delete note",
            onDismiss = { confirmDelete = false },
            confirmText = "Delete",
            onConfirm = {
                confirmDelete = false
                viewModel.delete(onClose)
            },
        ) {
            Text("This note will be permanently deleted.", color = colors.textPrimary)
        }
    }
}
