package com.dotpanel.app.widgets.config

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dotpanel.app.core.util.daysLabel
import com.dotpanel.app.designsystem.AccentDot
import com.dotpanel.app.designsystem.DotButton
import com.dotpanel.app.designsystem.DotCard
import com.dotpanel.app.designsystem.DotChip
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.designsystem.SwitchRow
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.UpcomingEvent
import com.dotpanel.app.domain.model.WidgetConfig
import com.dotpanel.app.domain.model.WidgetType

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WidgetConfigScreen(
    state: WidgetConfigUiState,
    onEdit: (transform: (WidgetConfig) -> WidgetConfig) -> Unit,
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = DotTheme.colors
    val config = state.config
    val type = state.type

    Column(modifier.fillMaxSize().background(colors.background).statusBarsPadding().navigationBarsPadding()) {
        ScreenHeader(title = type?.title ?: "Widget", subtitle = "Widget settings")

        if (config == null || type == null) {
            Spacer(Modifier.weight(1f))
        } else {
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                when (type) {
                    WidgetType.CLOCK -> {
                        DotLabel("Time format")
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DotChip("24-hour", config.use24Hour, { onEdit { it.copy(use24Hour = true) } })
                            DotChip("12-hour", !config.use24Hour, { onEdit { it.copy(use24Hour = false) } })
                        }
                        Hint("The time updates itself every minute without using any battery.")
                    }

                    WidgetType.COUNTDOWN -> {
                        DotLabel("Event")
                        ChoiceRow(
                            title = "Next upcoming event",
                            detail = "Switches automatically when it passes",
                            selected = config.targetId == WidgetConfig.NO_TARGET,
                            onClick = { onEdit { it.copy(targetId = WidgetConfig.NO_TARGET) } },
                        )
                        state.events.forEach { upcoming: UpcomingEvent ->
                            ChoiceRow(
                                title = upcoming.event.title,
                                detail = daysLabel(upcoming.daysRemaining),
                                selected = config.targetId == upcoming.event.id,
                                onClick = { onEdit { it.copy(targetId = upcoming.event.id) } },
                            )
                        }
                        if (state.events.isEmpty()) Hint("You have no events yet. The widget will offer to create one.")
                    }

                    WidgetType.NOTES -> {
                        DotLabel("Note")
                        ChoiceRow(
                            title = "Latest note",
                            detail = "Pinned notes come first",
                            selected = config.targetId == WidgetConfig.NO_TARGET,
                            onClick = { onEdit { it.copy(targetId = WidgetConfig.NO_TARGET) } },
                        )
                        state.notes.forEach { note: Note ->
                            ChoiceRow(
                                title = note.displayTitle,
                                detail = if (note.pinned) "Pinned" else null,
                                selected = config.targetId == note.id,
                                onClick = { onEdit { it.copy(targetId = note.id) } },
                            )
                        }
                        if (state.notes.isEmpty()) Hint("You have no notes yet. The widget will offer to create one.")
                    }

                    WidgetType.GOALS -> {
                        DotCard(Modifier.fillMaxWidth()) {
                            SwitchRow(
                                label = "Hide completed goals",
                                checked = config.hideCompleted,
                                onCheckedChange = { checked -> onEdit { it.copy(hideCompleted = checked) } },
                                description = "Only unfinished goals are listed. Progress still counts all of them.",
                            )
                        }
                        Hint("Tap a goal's dot on the home screen to check it off.")
                    }

                    WidgetType.SUMMARY -> Hint(
                        "Shows your next event, today's goal progress and your latest note. " +
                            "Tap any section to open it.",
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            DotButton("Cancel", onCancel, filled = false, modifier = Modifier.weight(1f))
            DotButton("Done", onConfirm, enabled = config != null, modifier = Modifier.weight(1f))
        }
    }
}

private val WidgetType.title: String
    get() = when (this) {
        WidgetType.CLOCK -> "Clock"
        WidgetType.COUNTDOWN -> "Countdown"
        WidgetType.GOALS -> "Goals"
        WidgetType.NOTES -> "Note"
        WidgetType.SUMMARY -> "Summary"
    }

@Composable
private fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = DotTheme.colors.textSecondary)
}

@Composable
private fun ChoiceRow(title: String, detail: String?, selected: Boolean, onClick: () -> Unit) {
    val colors = DotTheme.colors
    DotCard(Modifier.fillMaxWidth(), onClick = onClick, padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (detail != null) {
                    Text(detail, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                }
            }
            if (selected) AccentDot(Modifier.padding(start = 12.dp), size = 10.dp)
        }
    }
}
