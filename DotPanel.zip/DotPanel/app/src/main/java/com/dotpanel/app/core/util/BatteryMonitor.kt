package com.dotpanel.app.core.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate

data class BatteryInfo(val level: Int, val isCharging: Boolean, val temperatureC: Float?)

/**
 * Battery state from the sticky ACTION_BATTERY_CHANGED broadcast. The receiver is only registered
 * while something collects the flow (the dashboard being visible), so it costs nothing otherwise.
 */
@Singleton
class BatteryMonitor @Inject constructor(@ApplicationContext private val context: Context) {

    val batteryInfo: Flow<BatteryInfo?> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                trySend(parse(intent))
            }
        }
        val sticky = ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        trySend(sticky?.let(::parse))
        awaitClose { context.unregisterReceiver(receiver) }
    }.conflate()

    private fun parse(intent: Intent): BatteryInfo? {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return null
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            .takeIf { it != Int.MIN_VALUE }?.let { it / 10f }
        return BatteryInfo(level * 100 / scale, charging, temp)
    }
}
