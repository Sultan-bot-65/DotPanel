package com.dotpanel.app.data.backup

import com.dotpanel.app.database.DashboardCardEntity
import com.dotpanel.app.database.DashboardPresetEntity
import com.dotpanel.app.database.EventEntity
import com.dotpanel.app.database.GoalCompletionEntity
import com.dotpanel.app.database.GoalEntity
import com.dotpanel.app.database.NoteEntity
import com.dotpanel.app.domain.model.CardSize
import com.dotpanel.app.domain.model.CardType
import com.dotpanel.app.domain.model.EventCategory
import com.dotpanel.app.domain.model.NoteColor
import com.dotpanel.app.domain.model.Recurrence
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json

/** Thrown for any backup that is malformed, from a different app, too new, or internally inconsistent. */
class BackupException(message: String, cause: Throwable? = null) : Exception(message, cause)

@Serializable
data class BackupFile(
    val app: String = BackupCodec.APP_ID,
    val schemaVersion: Int = BackupCodec.SCHEMA_VERSION,
    val exportedAt: Long = 0,
    val presets: List<DashboardPresetEntity> = emptyList(),
    val cards: List<DashboardCardEntity> = emptyList(),
    val events: List<EventEntity> = emptyList(),
    val notes: List<NoteEntity> = emptyList(),
    val goals: List<GoalEntity> = emptyList(),
    val completions: List<GoalCompletionEntity> = emptyList(),
)

/**
 * Encodes and decodes backups. Pure Kotlin (no Android types) so it is unit-tested on the JVM.
 * Decoding NEVER touches the database: it parses and validates first, and the caller only writes
 * once a fully valid [BackupFile] is returned.
 */
object BackupCodec {
    const val APP_ID = "DotPanel"
    const val SCHEMA_VERSION = 1
    const val MAX_BYTES = 10 * 1024 * 1024
    private const val MAX_ROWS = 20_000
    private const val MAX_EPOCH_DAY = 1_000_000L // roughly the year 4700; keeps java.time safe

    private val json = Json {
        prettyPrint = true
        encodeDefaults = true
        ignoreUnknownKeys = true // forward compatible with additive changes
    }

    fun encode(file: BackupFile): String = json.encodeToString(BackupFile.serializer(), file)

    fun decode(text: String): BackupFile {
        val file = try {
            json.decodeFromString(BackupFile.serializer(), text)
        } catch (e: SerializationException) {
            throw BackupException("This is not a valid DotPanel backup file.", e)
        } catch (e: IllegalArgumentException) {
            throw BackupException("This is not a valid DotPanel backup file.", e)
        }
        validate(file)
        return file
    }

    fun validate(file: BackupFile) {
        fun fail(msg: String): Nothing = throw BackupException(msg)

        if (file.app != APP_ID) fail("This file was not created by DotPanel.")
        if (file.schemaVersion < 1) fail("Invalid backup version.")
        if (file.schemaVersion > SCHEMA_VERSION) {
            fail("This backup was made by a newer version of DotPanel. Please update the app.")
        }
        listOf(file.presets.size, file.cards.size, file.events.size, file.notes.size, file.goals.size, file.completions.size)
            .forEach { if (it > MAX_ROWS) fail("Backup contains too many entries.") }

        if (file.presets.isEmpty()) fail("Backup has no dashboard preset.")
        val presetIds = file.presets.map { it.id }
        if (presetIds.size != presetIds.toSet().size) fail("Duplicate dashboard presets.")
        file.presets.forEach { if (it.name.isBlank() || it.name.length > 60) fail("Invalid preset name.") }

        if (file.cards.map { it.id }.let { it.size != it.toSet().size }) fail("Duplicate dashboard cards.")
        file.cards.forEach { c ->
            if (c.presetId !in presetIds) fail("A dashboard card points to a missing preset.")
            if (enumValues<CardType>().none { it.name == c.type }) fail("Unknown card type '${c.type}'.")
            if (enumValues<CardSize>().none { it.name == c.size }) fail("Unknown card size '${c.size}'.")
            if (c.title.length > 100 || c.content.length > 5_000) fail("A dashboard card is too large.")
            if (c.position < 0) fail("Invalid card position.")
        }

        if (file.events.map { it.id }.let { it.size != it.toSet().size }) fail("Duplicate events.")
        file.events.forEach { e ->
            if (e.title.isBlank() || e.title.length > 120) fail("An event has an invalid title.")
            if (e.dateEpochDay !in -MAX_EPOCH_DAY..MAX_EPOCH_DAY) fail("An event has an invalid date.")
            if (enumValues<EventCategory>().none { it.name == e.category }) fail("Unknown event category '${e.category}'.")
            if (enumValues<Recurrence>().none { it.name == e.recurrence }) fail("Unknown recurrence '${e.recurrence}'.")
            if (e.notes.length > 2_000) fail("An event note is too long.")
            if (e.reminderOffsets.isNotBlank()) {
                e.reminderOffsets.split(',').forEach {
                    val n = it.trim().toIntOrNull()
                    if (n == null || n !in 0..365) fail("An event has an invalid reminder.")
                }
            }
        }

        if (file.notes.map { it.id }.let { it.size != it.toSet().size }) fail("Duplicate notes.")
        file.notes.forEach { n ->
            if (enumValues<NoteColor>().none { it.name == n.color }) fail("Unknown note colour '${n.color}'.")
            if (n.title.length > 200 || n.content.length > 100_000) fail("A note is too large.")
        }

        val goalIds = file.goals.map { it.id }
        if (goalIds.size != goalIds.toSet().size) fail("Duplicate goals.")
        file.goals.forEach { g ->
            if (g.title.isBlank() || g.title.length > 120) fail("A goal has an invalid title.")
            if (g.createdEpochDay !in -MAX_EPOCH_DAY..MAX_EPOCH_DAY) fail("A goal has an invalid date.")
        }

        if (file.completions.map { it.id }.let { it.size != it.toSet().size }) fail("Duplicate completion records.")
        val pairs = HashSet<Pair<Long, Long>>()
        file.completions.forEach { c ->
            if (c.goalId !in goalIds) fail("A completion record points to a missing goal.")
            if (c.epochDay !in -MAX_EPOCH_DAY..MAX_EPOCH_DAY) fail("A completion record has an invalid date.")
            if (!pairs.add(c.goalId to c.epochDay)) fail("Duplicate completion records.")
        }
    }
}
