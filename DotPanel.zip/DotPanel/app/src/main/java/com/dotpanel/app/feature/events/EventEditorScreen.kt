package com.dotpanel.app.feature.events

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.core.notifications.openNotificationSettings
import com.dotpanel.app.core.notifications.rememberNotificationPermission
import com.dotpanel.app.core.util.formatShort
import com.dotpanel.app.designsystem.DotButton
import com.dotpanel.app.designsystem.DotChip
import com.dotpanel.app.designsystem.DotDatePickerDialog
import com.dotpanel.app.designsystem.DotDialog
import com.dotpanel.app.designsystem.DotIconButton
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTextField
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.EmptyState
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.domain.model.EventCategory
import com.dotpanel.app.domain.model.Recurrence
import com.dotpanel.app.domain.model.ReminderOptions

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EventEditorScreen(
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: EventEditorViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showDatePicker by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var permissionDenied by remember { mutableStateOf(false) }
    val notificationPermission = rememberNotificationPermission { granted -> permissionDenied = !granted }

    Column(modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        ScreenHeader(
            title = if (viewModel.isNew) "New event" else "Edit event",
            navigationIcon = { DotIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "Back", onClose) },
            actions = {
                if (!viewModel.isNew) DotIconButton(Icons.Outlined.Delete, "Delete event", { confirmDelete = true })
            },
        )

        if (state.notFound) {
            EmptyState("This event no longer exists.")
            return@Column
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            DotTextField(state.title, viewModel::setTitle, "Title")

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DotLabel("Date")
                DotButton(state.date.formatShort(), { showDatePicker = true }, filled = false, modifier = Modifier.fillMaxWidth())
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DotLabel("Category")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    EventCategory.entries.forEach { category ->
                        DotChip(category.label, state.category == category, { viewModel.setCategory(category) })
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DotLabel("Repeats")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Recurrence.entries.forEach { recurrence ->
                        DotChip(recurrence.label, state.recurrence == recurrence, { viewModel.setRecurrence(recurrence) })
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DotLabel("Remind me")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReminderOptions.all.forEach { (offset, label) ->
                        DotChip(
                            text = label,
                            selected = offset in state.reminderOffsets,
                            onClick = {
                                val turningOn = offset !in state.reminderOffsets
                                viewModel.toggleReminder(offset)
                                if (turningOn && !notificationPermission.isGranted) notificationPermission.request()
                            },
                        )
                    }
                }
                if (state.reminderOffsets.isNotEmpty() && !notificationPermission.isGranted) {
                    Text(
                        "Notifications are turned off for DotPanel, so reminders can't be shown.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DotTheme.colors.textSecondary,
                    )
                    DotButton(
                        text = if (permissionDenied) "Open settings" else "Allow notifications",
                        onClick = {
                            if (permissionDenied) openNotificationSettings(context) else notificationPermission.request()
                        },
                        filled = false,
                    )
                }
            }

            DotTextField(state.notes, viewModel::setNotes, "Notes (optional)", singleLine = false, minLines = 3)
            Spacer(Modifier.height(8.dp))
        }

        Row(Modifier.fillMaxWidth().padding(20.dp)) {
            DotButton(
                text = "Save",
                onClick = { viewModel.save(onClose) },
                enabled = state.canSave,
                icon = Icons.Outlined.Check,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }

    if (showDatePicker) {
        DotDatePickerDialog(
            initial = state.date,
            onDismiss = { showDatePicker = false },
            onConfirm = {
                viewModel.setDate(it)
                showDatePicker = false
            },
        )
    }
    if (confirmDelete) {
        DotDialog(
            title = "Delete event",
            onDismiss = { confirmDelete = false },
            confirmText = "Delete",
            onConfirm = {
                confirmDelete = false
                viewModel.delete(onClose)
            },
        ) {
            Text("“${state.title}” and its reminders will be removed.", color = DotTheme.colors.textPrimary)
        }
    }
}
