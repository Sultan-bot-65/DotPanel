package com.dotpanel.app.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/*
 * Room entities. Enums are stored by name (String) so adding a value never needs a migration and a
 * JSON backup stays human-readable. The entities are also @Serializable so the backup format is a
 * direct, validated mirror of the schema.
 */

@Serializable
@Entity(tableName = "dashboard_presets")
data class DashboardPresetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
)

@Serializable
@Entity(
    tableName = "dashboard_cards",
    foreignKeys = [
        ForeignKey(
            entity = DashboardPresetEntity::class,
            parentColumns = ["id"],
            childColumns = ["presetId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("presetId")],
)
data class DashboardCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val presetId: Long,
    val type: String,
    val title: String,
    val content: String = "",
    val size: String,
    val position: Int,
    val visible: Boolean = true,
)

@Serializable
@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val dateEpochDay: Long,
    val category: String,
    val recurrence: String,
    /** Comma separated "days before" offsets, e.g. "0,1,7". Empty = no reminders. */
    val reminderOffsets: String = "",
    val notes: String = "",
)

@Serializable
@Entity(tableName = "notes", indices = [Index("pinned"), Index("updatedAt")])
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val color: String,
    val pinned: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long,
)

@Serializable
@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdEpochDay: Long,
    /** Removed goals are archived, never deleted, so history survives. */
    val archived: Boolean = false,
)

@Serializable
@Entity(
    tableName = "goal_completions",
    foreignKeys = [
        ForeignKey(
            entity = GoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["goalId", "epochDay"], unique = true), Index("epochDay")],
)
data class GoalCompletionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val goalId: Long,
    val epochDay: Long,
)

/** Per-instance configuration of a home-screen widget. Device specific, so not part of backups. */
@Entity(tableName = "widget_configurations")
data class WidgetConfigurationEntity(
    @PrimaryKey val appWidgetId: Int,
    val widgetType: String,
    val targetId: Long = -1,
    val use24Hour: Boolean = true,
    val hideCompleted: Boolean = false,
)
