package com.dotpanel.app.domain.model

import java.time.LocalDate

// ---- Notes ---------------------------------------------------------------------------------

enum class NoteColor(val label: String, val argb: Long) {
    NONE("None", 0xFF666666),
    RED("Red", 0xFFE51B23),
    AMBER("Amber", 0xFFF2A900),
    GREEN("Green", 0xFF2FB36B),
    BLUE("Blue", 0xFF3D7BFF),
    PURPLE("Purple", 0xFF9B5DE5),
}

data class Note(
    val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val color: NoteColor = NoteColor.NONE,
    val pinned: Boolean = false,
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
) {
    val isBlank: Boolean get() = title.isBlank() && content.isBlank()
    val displayTitle: String get() = title.ifBlank { content.lineSequence().firstOrNull().orEmpty().ifBlank { "Untitled" } }
}

// ---- Goals ---------------------------------------------------------------------------------

data class Goal(val id: Long = 0, val title: String, val createdEpochDay: Long)

data class GoalCompletion(val goalId: Long, val epochDay: Long)

data class DayProgress(val date: LocalDate, val completed: Int, val total: Int) {
    val fraction: Float get() = if (total == 0) 0f else completed.toFloat() / total
    val percent: Int get() = (fraction * 100).toInt()
}

data class GoalStats(
    val total: Int,
    val completedToday: Int,
    val currentStreak: Int,
    val bestStreak: Int,
    val history: List<DayProgress>,
) {
    val percentToday: Int get() = if (total == 0) 0 else completedToday * 100 / total
    val fractionToday: Float get() = if (total == 0) 0f else completedToday.toFloat() / total
}

// ---- Settings ------------------------------------------------------------------------------

enum class ThemeMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val use24HourClock: Boolean = true,
    val activePresetId: Long = -1L,
    val eventReminderHour: Int = 9,
    val goalReminderEnabled: Boolean = false,
    val goalReminderHour: Int = 20,
)

// ---- Widgets -------------------------------------------------------------------------------

enum class WidgetType { CLOCK, COUNTDOWN, GOALS, NOTES, SUMMARY }

data class WidgetConfig(
    val appWidgetId: Int,
    val type: WidgetType,
    /** Event id (countdown) or note id (notes); [NO_TARGET] means "choose automatically". */
    val targetId: Long = NO_TARGET,
    val use24Hour: Boolean = true,
    val hideCompleted: Boolean = false,
) {
    companion object {
        const val NO_TARGET = -1L
    }
}
