package com.dotpanel.app.core.di

import com.dotpanel.app.core.notifications.WorkReminderScheduler
import com.dotpanel.app.data.backup.BackupRepositoryImpl
import com.dotpanel.app.data.repository.DashboardRepositoryImpl
import com.dotpanel.app.data.repository.EventRepositoryImpl
import com.dotpanel.app.data.repository.GoalRepositoryImpl
import com.dotpanel.app.data.repository.NoteRepositoryImpl
import com.dotpanel.app.data.repository.WidgetConfigRepositoryImpl
import com.dotpanel.app.data.settings.SettingsRepositoryImpl
import com.dotpanel.app.domain.repository.BackupRepository
import com.dotpanel.app.domain.repository.DashboardRepository
import com.dotpanel.app.domain.repository.EventRepository
import com.dotpanel.app.domain.repository.GoalRepository
import com.dotpanel.app.domain.repository.NoteRepository
import com.dotpanel.app.domain.repository.ReminderScheduler
import com.dotpanel.app.domain.repository.SettingsRepository
import com.dotpanel.app.domain.repository.WidgetConfigRepository
import com.dotpanel.app.domain.repository.WidgetRefresher
import com.dotpanel.app.widgets.GlanceWidgetRefresher
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** Binds domain interfaces to their implementations: the only place layers are wired together. */
@Module
@InstallIn(SingletonComponent::class)
abstract class BindingsModule {
    @Binds @Singleton abstract fun dashboard(impl: DashboardRepositoryImpl): DashboardRepository
    @Binds @Singleton abstract fun events(impl: EventRepositoryImpl): EventRepository
    @Binds @Singleton abstract fun notes(impl: NoteRepositoryImpl): NoteRepository
    @Binds @Singleton abstract fun goals(impl: GoalRepositoryImpl): GoalRepository
    @Binds @Singleton abstract fun settings(impl: SettingsRepositoryImpl): SettingsRepository
    @Binds @Singleton abstract fun widgetConfig(impl: WidgetConfigRepositoryImpl): WidgetConfigRepository
    @Binds @Singleton abstract fun backup(impl: BackupRepositoryImpl): BackupRepository
    @Binds @Singleton abstract fun reminders(impl: WorkReminderScheduler): ReminderScheduler
    @Binds @Singleton abstract fun widgetRefresher(impl: GlanceWidgetRefresher): WidgetRefresher
}
