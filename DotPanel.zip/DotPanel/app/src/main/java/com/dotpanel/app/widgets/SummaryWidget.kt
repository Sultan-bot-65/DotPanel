package com.dotpanel.app.widgets

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.width
import androidx.glance.text.Text
import com.dotpanel.app.core.util.daysLabel
import com.dotpanel.app.core.util.formatDayMonth
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.UpcomingEvent
import com.dotpanel.app.domain.usecase.GoalStatsCalculator
import com.dotpanel.app.navigation.Routes

private class SummarySnapshot(
    val dateLabel: String,
    val nextEvent: UpcomingEvent?,
    val goalsDone: Int,
    val goalsTotal: Int,
    val note: Note?,
)

/** Next event, today's goal progress and the latest note in one widget; each part opens its own screen. */
class SummaryWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val entry = context.widgetEntryPoint()
        val today = entry.dateProvider().today()

        val upcoming = entry.events().getEvents().map { it.toUpcoming(today) }
        val stats = GoalStatsCalculator.calculate(entry.goals().getGoals(), entry.goals().getCompletions(), today)
        val snapshot = SummarySnapshot(
            dateLabel = today.formatDayMonth(),
            nextEvent = CountdownSelection.choose(upcoming, null),
            goalsDone = stats.completedToday,
            goalsTotal = stats.total,
            note = NoteSelection.choose(entry.notes().getNotes(), null),
        )

        provideContent {
            val size = LocalSize.current
            // Hide the lowest sections first when the widget is short.
            val showNote = size.height >= 170.dp
            WidgetFrame(onClick = openRoute(Routes.DASHBOARD)) {
                SummaryContent(snapshot, showNote, size.width - 24.dp)
            }
        }
    }
}

@Composable
private fun SummaryContent(s: SummarySnapshot, showNote: Boolean, innerWidth: Dp) {
    Column(modifier = GlanceModifier.fillMaxSize()) {
        Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Dot(WidgetColors.accent)
            Spacer(GlanceModifier.width(6.dp))
            Text("TODAY", style = widgetText(WidgetColors.textSecondary, 10.sp), maxLines = 1)
            Spacer(GlanceModifier.defaultWeight())
            Text(s.dateLabel.uppercase(), style = widgetText(WidgetColors.textSecondary, 10.sp), maxLines = 1)
        }
        Spacer(GlanceModifier.height(8.dp))

        Column(modifier = GlanceModifier.fillMaxWidth().clickable(openRoute(Routes.EVENTS))) {
            Text("NEXT EVENT", style = widgetText(WidgetColors.textSecondary, 9.sp), maxLines = 1)
            if (s.nextEvent == null) {
                Text("Nothing planned", style = widgetText(size = 13.sp, bold = true), maxLines = 1)
            } else {
                Text(s.nextEvent.event.title, style = widgetText(size = 13.sp, bold = true), maxLines = 1)
                Text(daysLabel(s.nextEvent.daysRemaining), style = widgetText(WidgetColors.accent, 12.sp), maxLines = 1)
            }
        }
        Spacer(GlanceModifier.height(8.dp))

        Column(modifier = GlanceModifier.fillMaxWidth().clickable(openRoute(Routes.GOALS))) {
            Row(modifier = GlanceModifier.fillMaxWidth()) {
                Text("GOALS", style = widgetText(WidgetColors.textSecondary, 9.sp), maxLines = 1)
                Spacer(GlanceModifier.defaultWeight())
                Text("${s.goalsDone}/${s.goalsTotal}", style = widgetText(size = 11.sp, bold = true), maxLines = 1)
            }
            Spacer(GlanceModifier.height(4.dp))
            DotProgressImage(
                fraction = if (s.goalsTotal == 0) 0f else s.goalsDone.toFloat() / s.goalsTotal,
                width = innerWidth,
            )
        }

        if (showNote) {
            Spacer(GlanceModifier.height(8.dp))
            Column(modifier = GlanceModifier.fillMaxWidth().clickable(openRoute(Routes.note(s.note?.id ?: Routes.NEW_ID)))) {
                Text("NOTE", style = widgetText(WidgetColors.textSecondary, 9.sp), maxLines = 1)
                Text(
                    s.note?.displayTitle ?: "No notes yet",
                    style = widgetText(size = 13.sp, bold = true),
                    maxLines = 2,
                )
            }
        }
    }
}

class SummaryWidgetReceiver : DotPanelWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = SummaryWidget()
}
