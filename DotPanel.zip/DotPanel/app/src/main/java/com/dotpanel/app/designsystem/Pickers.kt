package com.dotpanel.app.designsystem

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.dotpanel.app.core.util.formatHour
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** Material date picker restyled to the DotPanel palette. Material works in UTC milliseconds. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DotDatePickerDialog(
    initial: LocalDate,
    onDismiss: () -> Unit,
    onConfirm: (LocalDate) -> Unit,
) {
    val c = DotTheme.colors
    val state = rememberDatePickerState(
        initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
    )
    val pickerColors = DatePickerDefaults.colors(
        containerColor = c.card,
        selectedDayContainerColor = c.accent,
        selectedDayContentColor = androidx.compose.ui.graphics.Color.White,
        todayDateBorderColor = c.accent,
        todayContentColor = c.accent,
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        colors = pickerColors,
        confirmButton = {
            TextButton(
                enabled = state.selectedDateMillis != null,
                onClick = {
                    state.selectedDateMillis?.let {
                        onConfirm(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate())
                    }
                },
            ) { Text("OK", style = MaterialTheme.typography.labelLarge, color = c.accent) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", style = MaterialTheme.typography.labelLarge, color = c.textSecondary)
            }
        },
    ) {
        DatePicker(state = state, colors = pickerColors)
    }
}

/** "−  20:00  +" control for choosing an hour of the day without a full time-picker dialog. */
@Composable
fun HourStepper(
    hour: Int,
    use24Hour: Boolean,
    onHourChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        DotIconButton(Icons.Outlined.Remove, "Earlier hour", { onHourChange((hour + 23) % 24) })
        Text(
            formatHour(hour, use24Hour),
            modifier = Modifier.width(76.dp),
            style = MaterialTheme.typography.titleMedium,
            color = DotTheme.colors.textPrimary,
            textAlign = TextAlign.Center,
        )
        DotIconButton(Icons.Outlined.Add, "Later hour", { onHourChange((hour + 1) % 24) })
    }
}
