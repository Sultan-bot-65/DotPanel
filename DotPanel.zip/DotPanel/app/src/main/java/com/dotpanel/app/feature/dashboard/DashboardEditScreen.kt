package com.dotpanel.app.feature.dashboard

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DragHandle
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.designsystem.DotButton
import com.dotpanel.app.designsystem.DotCard
import com.dotpanel.app.designsystem.DotChip
import com.dotpanel.app.designsystem.DotDialog
import com.dotpanel.app.designsystem.DotIconButton
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTextField
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.EmptyState
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.designsystem.SwitchRow
import com.dotpanel.app.designsystem.dragContainer
import com.dotpanel.app.designsystem.rememberDragDropState
import com.dotpanel.app.domain.model.CardSize
import com.dotpanel.app.domain.model.CardType
import com.dotpanel.app.domain.model.DashboardCard

private sealed interface EditDialog {
    data object AddCard : EditDialog
    data class EditCard(val card: DashboardCard) : EditDialog
    data object NewPreset : EditDialog
    data object RenamePreset : EditDialog
    data object DeletePreset : EditDialog
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DashboardEditScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: DashboardEditViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<EditDialog?>(null) }

    // Local, mutable copy of the order so dragging is instant; persisted when the finger lifts.
    val local = remember { mutableStateListOf<DashboardCard>() }
    val listState = rememberLazyListState()
    val dragState = rememberDragDropState(
        listState = listState,
        onMove = { from, to -> local.add(to, local.removeAt(from)) },
        onDragEnd = { viewModel.saveOrder(local.map { it.id }) },
    )
    LaunchedEffect(state.cards) {
        if (dragState.draggingItemIndex == null) {
            local.clear()
            local.addAll(state.cards)
        }
    }

    Column(modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        ScreenHeader(
            title = "Layout",
            subtitle = "Long-press a card, then drag to reorder",
            navigationIcon = { DotIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "Back", onBack) },
            actions = { DotIconButton(Icons.Outlined.Add, "Add card", { dialog = EditDialog.AddCard }, filled = true) },
        )

        // Presets
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(state.presets, key = { it.id }) { preset ->
                DotChip(preset.name, preset.id == state.active?.id, onClick = { viewModel.selectPreset(preset.id) })
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            DotButton("New", { dialog = EditDialog.NewPreset }, filled = false, icon = Icons.Outlined.Add)
            DotButton("Rename", { dialog = EditDialog.RenamePreset }, filled = false, enabled = state.active != null)
            DotButton("Delete", { dialog = EditDialog.DeletePreset }, filled = false, enabled = state.presets.size > 1)
        }
        Spacer(Modifier.height(4.dp))

        if (local.isEmpty()) {
            EmptyState("No cards in this preset.", hint = "Tap + to add one")
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 20.dp)
                    .dragContainer(dragState),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                itemsIndexed(local, key = { _, card -> card.id }) { index, card ->
                    val dragging = index == dragState.draggingItemIndex
                    val itemModifier = if (dragging) {
                        Modifier
                            .zIndex(1f)
                            .graphicsLayer { translationY = dragState.draggingItemOffset; scaleX = 1.02f; scaleY = 1.02f }
                    } else {
                        Modifier.animateItem()
                    }
                    CardRow(
                        card = card,
                        modifier = itemModifier,
                        onSize = { viewModel.updateCard(card.copy(size = it)) },
                        onToggleVisible = { viewModel.updateCard(card.copy(visible = !card.visible)) },
                        onEdit = { dialog = EditDialog.EditCard(card) },
                        onDelete = { viewModel.deleteCard(card.id) },
                    )
                }
            }
        }
    }

    when (val d = dialog) {
        null -> Unit
        EditDialog.AddCard -> CardEditorDialog(
            initial = null,
            onDismiss = { dialog = null },
            onSave = { type, title, content, size ->
                viewModel.addCard(type, title, content, size)
                dialog = null
            },
        )
        is EditDialog.EditCard -> CardEditorDialog(
            initial = d.card,
            onDismiss = { dialog = null },
            onSave = { _, title, content, size ->
                viewModel.updateCard(d.card.copy(title = title.trim().take(100).ifBlank { d.card.type.label }, content = content.take(5_000), size = size))
                dialog = null
            },
        )
        EditDialog.NewPreset -> NameDialog(
            title = "New preset",
            initial = "",
            confirmText = "Create",
            extraToggleLabel = "Start with the default cards",
            onDismiss = { dialog = null },
            onConfirm = { name, withDefaults ->
                viewModel.createPreset(name, withDefaults)
                dialog = null
            },
        )
        EditDialog.RenamePreset -> NameDialog(
            title = "Rename preset",
            initial = state.active?.name.orEmpty(),
            confirmText = "Save",
            onDismiss = { dialog = null },
            onConfirm = { name, _ ->
                state.active?.let { viewModel.renamePreset(it.id, name) }
                dialog = null
            },
        )
        EditDialog.DeletePreset -> DotDialog(
            title = "Delete preset",
            onDismiss = { dialog = null },
            confirmText = "Delete",
            onConfirm = {
                viewModel.deleteActivePreset()
                dialog = null
            },
        ) {
            Text(
                "Delete \"${state.active?.name.orEmpty()}\" and all of its cards? Your notes, events and goals are not affected.",
                style = MaterialTheme.typography.bodyMedium,
                color = DotTheme.colors.textSecondary,
            )
        }
    }
}

@Composable
private fun CardRow(
    card: DashboardCard,
    onSize: (CardSize) -> Unit,
    onToggleVisible: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val alpha = if (card.visible) 1f else 0.5f
    DotCard(modifier.fillMaxWidth(), padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.DragHandle, "Drag handle", Modifier.size(24.dp), tint = DotTheme.colors.textSecondary)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    card.title.ifBlank { card.type.label },
                    style = MaterialTheme.typography.titleMedium,
                    color = DotTheme.colors.textPrimary.copy(alpha = alpha),
                    maxLines = 1,
                )
                DotLabel(card.type.label + if (!card.visible) " · hidden" else "")
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CardSize.entries.forEach { size -> DotChip(size.short, card.size == size, onClick = { onSize(size) }) }
            Spacer(Modifier.weight(1f))
            DotIconButton(if (card.visible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff, if (card.visible) "Hide card" else "Show card", onToggleVisible)
            DotIconButton(Icons.Outlined.Edit, "Edit card", onEdit)
            DotIconButton(Icons.Outlined.Delete, "Delete card", onDelete)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CardEditorDialog(
    initial: DashboardCard?,
    onDismiss: () -> Unit,
    onSave: (CardType, String, String, CardSize) -> Unit,
) {
    var type by remember { mutableStateOf(initial?.type ?: CardType.CLOCK) }
    var title by remember { mutableStateOf(initial?.title ?: CardType.CLOCK.label) }
    var content by remember { mutableStateOf(initial?.content.orEmpty()) }
    var size by remember { mutableStateOf(initial?.size ?: CardSize.MEDIUM) }

    DotDialog(
        title = if (initial == null) "Add card" else "Edit card",
        onDismiss = onDismiss,
        confirmText = "Save",
        onConfirm = { onSave(type, title, content, size) },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (initial == null) {
                DotLabel("Type")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardType.entries.forEach { t ->
                        DotChip(t.label, type == t, onClick = {
                            // Keep the title in sync with the type until the user customises it.
                            if (title.isBlank() || title == type.label) title = t.label
                            type = t
                        })
                    }
                }
            }
            DotTextField(title, { title = it.take(100) }, "Title")
            if (type == CardType.CUSTOM_TEXT) {
                DotTextField(content, { content = it.take(5_000) }, "Text", singleLine = false, minLines = 3, maxLines = 8)
            }
            DotLabel("Size")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CardSize.entries.forEach { s -> DotChip(s.label, size == s, onClick = { size = s }) }
            }
        }
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: (String, Boolean) -> Unit,
    extraToggleLabel: String? = null,
) {
    var name by remember { mutableStateOf(initial) }
    var toggle by remember { mutableStateOf(true) }
    DotDialog(
        title = title,
        onDismiss = onDismiss,
        confirmText = confirmText,
        confirmEnabled = name.isNotBlank(),
        onConfirm = { onConfirm(name, toggle) },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DotTextField(name, { name = it.take(60) }, "Name")
            if (extraToggleLabel != null) SwitchRow(extraToggleLabel, toggle, { toggle = it })
        }
    }
}
