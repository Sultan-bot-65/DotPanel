package com.dotpanel.app.domain.usecase

import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.model.GoalStats
import com.dotpanel.app.domain.repository.GoalRepository
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

/** Live goal statistics; recomputes when goals/completions change or the date rolls over. */
class ObserveGoalStatsUseCase @Inject constructor(
    private val goals: GoalRepository,
    private val dateProvider: DateProvider,
) {
    operator fun invoke(historyDays: Int = 14): Flow<GoalStats> =
        combine(goals.observeGoals(), goals.observeCompletions(), dateProvider.todayFlow) { g, c, today ->
            GoalStatsCalculator.calculate(g, c, today, historyDays)
        }
}
