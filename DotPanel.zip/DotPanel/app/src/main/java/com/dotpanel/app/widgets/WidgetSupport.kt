package com.dotpanel.app.widgets

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.glance.ColorFilter
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalContext
import androidx.glance.action.Action
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.color.ColorProvider
import androidx.glance.layout.Box
import androidx.glance.layout.ContentScale
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontFamily
import androidx.glance.text.FontWeight
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import com.dotpanel.app.core.util.deepLinkIntent
import androidx.glance.unit.ColorProvider as GlanceColorProvider

/** DotPanel palette as day/night providers; the system picks the right one, no redraw needed. */
internal object WidgetColors {
    val background = ColorProvider(day = Color(0xFFF4F4F4), night = Color(0xFF080808))
    val card = ColorProvider(day = Color(0xFFFFFFFF), night = Color(0xFF1D1D1D))
    val textPrimary = ColorProvider(day = Color(0xFF0A0A0A), night = Color(0xFFFFFFFF))
    val textSecondary = ColorProvider(day = Color(0xFF6B6B6B), night = Color(0xFF999999))
    val accent = ColorProvider(day = Color(0xFFE51B23), night = Color(0xFFE51B23))
    val border = ColorProvider(day = Color(0xFFD2D2D2), night = Color(0xFF303030))

    /** A fixed colour (for note labels), identical in both themes. */
    fun fixed(color: Color): androidx.glance.unit.ColorProvider = GlanceColorProvider(color)
}

internal fun widgetText(
    color: androidx.glance.unit.ColorProvider = WidgetColors.textPrimary,
    size: TextUnit,
    bold: Boolean = false,
    align: TextAlign? = null,
) = TextStyle(
    color = color,
    fontSize = size,
    fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
    fontFamily = FontFamily.Monospace,
    textAlign = align,
)

/** Opens DotPanel at [route] when the widget (or a part of it) is tapped. */
@Composable
internal fun openRoute(route: String): Action = actionStartActivity(deepLinkIntent(LocalContext.current, route))

/** The rounded, bordered surface every widget sits on. [onClick] makes the whole surface tappable. */
@Composable
internal fun WidgetFrame(onClick: Action?, content: @Composable () -> Unit) {
    val base = GlanceModifier
        .fillMaxSize()
        .background(WidgetColors.background)
        .cornerRadius(22.dp)
    Box(
        modifier = (if (onClick != null) base.clickable(onClick) else base).padding(12.dp),
    ) { content() }
}

/** A small filled circle, e.g. the red accent dot or a note colour label. */
@Composable
internal fun Dot(color: androidx.glance.unit.ColorProvider, size: Dp = 6.dp) {
    Box(
        modifier = GlanceModifier.size(size).background(color).cornerRadius(size / 2),
        content = {},
    )
}

/** [text] in dot-matrix type, shrunk if necessary to fit inside [maxWidth] x [maxHeight]. */
@Composable
internal fun DotTextImage(
    text: String,
    maxWidth: Dp,
    maxHeight: Dp,
    maxDot: Dp = 7.dp,
    tint: androidx.glance.unit.ColorProvider = WidgetColors.textPrimary,
    description: String = text,
) {
    val context = LocalContext.current
    val image = DotBitmap.text(context, text, DotBitmap.fitDot(text, maxWidth, maxHeight, maxDot))
    Image(
        provider = ImageProvider(image.bitmap),
        contentDescription = description,
        modifier = GlanceModifier.width(image.width).height(image.height),
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.tint(tint),
    )
}

/** A dot-matrix progress bar, [width] x [height], filled to [fraction]. */
@Composable
internal fun DotProgressImage(fraction: Float, width: Dp, height: Dp = 8.dp, segments: Int = 20) {
    val context: Context = LocalContext.current
    val image = DotBitmap.progress(context, fraction, segments, width, height)
    Image(
        provider = ImageProvider(image.bitmap),
        contentDescription = "${(fraction * 100).toInt()} percent",
        modifier = GlanceModifier.width(image.width).height(image.height),
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.tint(WidgetColors.accent),
    )
}
