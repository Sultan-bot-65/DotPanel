package com.dotpanel.app.feature.events

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.model.Event
import com.dotpanel.app.domain.model.EventCategory
import com.dotpanel.app.domain.model.Recurrence
import com.dotpanel.app.domain.repository.EventRepository
import com.dotpanel.app.navigation.Routes
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EventEditorState(
    val loading: Boolean = true,
    val notFound: Boolean = false,
    val title: String = "",
    val date: LocalDate = LocalDate.now(),
    val category: EventCategory = EventCategory.OTHER,
    val recurrence: Recurrence = Recurrence.NONE,
    val reminderOffsets: Set<Int> = emptySet(),
    val notes: String = "",
) {
    val canSave: Boolean get() = title.isNotBlank()
}

@HiltViewModel
class EventEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val events: EventRepository,
    dateProvider: DateProvider,
) : ViewModel() {

    private val eventId: Long = savedStateHandle.get<Long>("id") ?: Routes.NEW_ID
    val isNew: Boolean = eventId == Routes.NEW_ID

    private val _state = MutableStateFlow(EventEditorState(date = dateProvider.today()))
    val state: StateFlow<EventEditorState> = _state.asStateFlow()

    init {
        if (isNew) {
            _state.update { it.copy(loading = false) }
        } else {
            viewModelScope.launch {
                val event = events.getEvent(eventId)
                _state.update {
                    if (event == null) {
                        it.copy(loading = false, notFound = true)
                    } else {
                        EventEditorState(
                            loading = false,
                            title = event.title,
                            date = event.date,
                            category = event.category,
                            recurrence = event.recurrence,
                            reminderOffsets = event.reminderOffsets,
                            notes = event.notes,
                        )
                    }
                }
            }
        }
    }

    fun setTitle(value: String) = _state.update { it.copy(title = value.take(120)) }
    fun setDate(value: LocalDate) = _state.update { it.copy(date = value) }
    fun setCategory(value: EventCategory) = _state.update { it.copy(category = value) }
    fun setRecurrence(value: Recurrence) = _state.update { it.copy(recurrence = value) }
    fun setNotes(value: String) = _state.update { it.copy(notes = value.take(2_000)) }

    fun toggleReminder(offsetDays: Int) = _state.update {
        val next = if (offsetDays in it.reminderOffsets) it.reminderOffsets - offsetDays else it.reminderOffsets + offsetDays
        it.copy(reminderOffsets = next)
    }

    fun save(onDone: () -> Unit) {
        val s = _state.value
        if (!s.canSave) return
        viewModelScope.launch {
            events.upsert(
                Event(
                    id = if (isNew) 0 else eventId,
                    title = s.title,
                    date = s.date,
                    category = s.category,
                    recurrence = s.recurrence,
                    reminderOffsets = s.reminderOffsets,
                    notes = s.notes,
                ),
            )
            onDone()
        }
    }

    fun delete(onDone: () -> Unit) {
        if (isNew) return
        viewModelScope.launch {
            events.delete(eventId)
            onDone()
        }
    }
}
