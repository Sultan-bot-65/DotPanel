package com.dotpanel.app.feature.notes

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.core.di.ApplicationScope
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.NoteColor
import com.dotpanel.app.domain.repository.NoteRepository
import com.dotpanel.app.navigation.Routes
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class SaveStatus { IDLE, SAVING, SAVED }

data class NoteEditorState(
    val loading: Boolean = true,
    val notFound: Boolean = false,
    val title: String = "",
    val content: String = "",
    val color: NoteColor = NoteColor.NONE,
    val pinned: Boolean = false,
    val status: SaveStatus = SaveStatus.IDLE,
)

/**
 * Auto-saving editor. Edits are debounced; [flush] writes immediately and runs on the application
 * scope so a final save survives the screen (and this ViewModel) being torn down.
 */
@HiltViewModel
class NoteEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val notes: NoteRepository,
    @ApplicationScope private val appScope: CoroutineScope,
) : ViewModel() {

    private val requestedId: Long = savedStateHandle.get<Long>("id") ?: Routes.NEW_ID

    private val _state = MutableStateFlow(NoteEditorState())
    val state: StateFlow<NoteEditorState> = _state.asStateFlow()

    // Persistence bookkeeping, only touched while holding [lock].
    private val lock = Mutex()
    private var persistedId: Long = if (requestedId == Routes.NEW_ID) 0L else requestedId
    private var createdAt: Long = 0L
    private var discarded = false
    private var saveJob: Job? = null

    init {
        if (requestedId == Routes.NEW_ID) {
            _state.update { it.copy(loading = false) }
        } else {
            viewModelScope.launch {
                val note = notes.getNote(requestedId)
                if (note == null) {
                    _state.update { it.copy(loading = false, notFound = true) }
                } else {
                    createdAt = note.createdAt
                    _state.update {
                        it.copy(
                            loading = false,
                            title = note.title,
                            content = note.content,
                            color = note.color,
                            pinned = note.pinned,
                            status = SaveStatus.SAVED,
                        )
                    }
                }
            }
        }
    }

    fun setTitle(value: String) = edit { it.copy(title = value.take(200)) }
    fun setContent(value: String) = edit { it.copy(content = value.take(100_000)) }
    fun setColor(value: NoteColor) = edit { it.copy(color = value) }
    fun togglePinned() = edit { it.copy(pinned = !it.pinned) }

    private fun edit(transform: (NoteEditorState) -> NoteEditorState) {
        if (_state.value.loading) return
        _state.update { transform(it).copy(status = SaveStatus.SAVING) }
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(AUTOSAVE_DELAY_MS)
            lock.withLock { writeLocked(deleteIfBlank = false) }
        }
    }

    /** Saves right now (leaving the screen, app going to background). Deletes a note emptied by the user. */
    fun flush() {
        saveJob?.cancel()
        appScope.launch { lock.withLock { writeLocked(deleteIfBlank = true) } }
    }

    fun delete(onDone: () -> Unit) {
        saveJob?.cancel()
        viewModelScope.launch {
            lock.withLock {
                discarded = true
                if (persistedId != 0L) notes.delete(persistedId)
            }
            onDone()
        }
    }

    private suspend fun writeLocked(deleteIfBlank: Boolean) {
        if (discarded) return
        val s = _state.value
        if (s.loading || s.notFound) return
        val note = Note(
            id = persistedId,
            title = s.title.trim(),
            content = s.content,
            color = s.color,
            pinned = s.pinned,
            createdAt = createdAt,
        )
        if (note.isBlank) {
            // Never store a blank note; remove one the user emptied when they leave.
            if (deleteIfBlank && persistedId != 0L) {
                notes.delete(persistedId)
                persistedId = 0L
                createdAt = 0L
            }
            _state.update { it.copy(status = SaveStatus.IDLE) }
            return
        }
        val id = notes.upsert(note)
        persistedId = id
        if (createdAt == 0L) createdAt = notes.getNote(id)?.createdAt ?: 0L
        _state.update { it.copy(status = SaveStatus.SAVED) }
    }

    private companion object {
        const val AUTOSAVE_DELAY_MS = 600L
    }
}
