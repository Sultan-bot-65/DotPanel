package com.dotpanel.app.feature.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.designsystem.DotCard
import com.dotpanel.app.designsystem.DotIconButton
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTextField
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.EmptyState
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.model.NoteColor
import com.dotpanel.app.navigation.Routes

fun NoteColor.toComposeColor(): Color = Color(argb)

@Composable
fun NotesScreen(
    onOpenNote: (Long) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: NotesViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier.fillMaxSize().statusBarsPadding()) {
        ScreenHeader(
            title = "Notes",
            subtitle = if (state.totalCount == 1) "1 note" else "${state.totalCount} notes",
            actions = { DotIconButton(Icons.Outlined.Add, "New note", { onOpenNote(Routes.NEW_ID) }, filled = true) },
        )
        Box(Modifier.padding(horizontal = 20.dp)) {
            DotTextField(state.query, viewModel::setQuery, "Search notes")
        }
        Spacer(Modifier.height(12.dp))

        when {
            state.loading -> Unit
            state.totalCount == 0 -> EmptyState("No notes yet.", hint = "Tap + to write your first one")
            state.isEmpty -> EmptyState("Nothing matches “${state.query.trim()}”.")
            else -> LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                if (state.pinned.isNotEmpty()) {
                    item(key = "pinned-header") { DotLabel("Pinned") }
                    items(state.pinned, key = { "p${it.id}" }) { NoteRow(it, onClick = { onOpenNote(it.id) }) }
                    if (state.others.isNotEmpty()) {
                        item(key = "others-header") { DotLabel("Notes", Modifier.padding(top = 10.dp)) }
                    }
                }
                items(state.others, key = { "n${it.id}" }) { NoteRow(it, onClick = { onOpenNote(it.id) }) }
            }
        }
    }
}

@Composable
private fun NoteRow(note: Note, onClick: () -> Unit) {
    val colors = DotTheme.colors
    DotCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.Top) {
            if (note.color != NoteColor.NONE) {
                Box(
                    Modifier
                        .padding(top = 6.dp)
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(note.color.toComposeColor()),
                )
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    note.displayTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val preview = if (note.title.isBlank()) {
                    note.content.lineSequence().drop(1).joinToString(" ").trim()
                } else {
                    note.content.replace('\n', ' ').trim()
                }
                if (preview.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        preview,
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (note.pinned) {
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Filled.Star, contentDescription = "Pinned", tint = colors.accent, modifier = Modifier.size(18.dp))
            }
        }
    }
}
