package com.dotpanel.app.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(
    entities = [
        DashboardPresetEntity::class,
        DashboardCardEntity::class,
        EventEntity::class,
        NoteEntity::class,
        GoalEntity::class,
        GoalCompletionEntity::class,
        WidgetConfigurationEntity::class,
    ],
    version = DotPanelDatabase.VERSION,
    exportSchema = true,
)
abstract class DotPanelDatabase : RoomDatabase() {
    abstract fun dashboardDao(): DashboardDao
    abstract fun eventDao(): EventDao
    abstract fun noteDao(): NoteDao
    abstract fun goalDao(): GoalDao
    abstract fun widgetConfigDao(): WidgetConfigDao

    companion object {
        const val VERSION = 1
        const val NAME = "dotpanel.db"
    }
}

/**
 * Migration registry. User data must survive updates, so the database is NEVER built with
 * fallbackToDestructiveMigration(). When bumping [DotPanelDatabase.VERSION]:
 *
 *  1. Write a `Migration(from, to)` below containing the SQL for the change.
 *  2. Add it to [ALL].
 *  3. Commit the new schema JSON that KSP exports to app/schemas/.
 *
 * Example:
 * ```
 * val MIGRATION_1_2 = object : Migration(1, 2) {
 *     override fun migrate(db: SupportSQLiteDatabase) {
 *         db.execSQL("ALTER TABLE events ADD COLUMN color TEXT NOT NULL DEFAULT ''")
 *     }
 * }
 * ```
 * The backup `schemaVersion` is independent of this number (see BackupCodec).
 */
object DotPanelMigrations {
    val ALL: Array<Migration> = emptyArray()
}
