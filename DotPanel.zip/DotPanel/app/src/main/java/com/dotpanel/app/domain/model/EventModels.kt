package com.dotpanel.app.domain.model

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.MonthDay
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

enum class EventCategory(val label: String) {
    BIRTHDAY("Birthday"),
    EXAM("Exam"),
    TRAVEL("Travel"),
    ANNIVERSARY("Anniversary"),
    WORK("Work"),
    OTHER("Other"),
}

enum class Recurrence(val label: String) {
    NONE("Once"),
    WEEKLY("Weekly"),
    MONTHLY("Monthly"),
    YEARLY("Yearly"),
}

/** Reminder offsets are "days before the occurrence"; 0 means on the day itself. */
object ReminderOptions {
    val all: List<Pair<Int, String>> = listOf(
        0 to "On the day",
        1 to "1 day before",
        3 to "3 days before",
        7 to "1 week before",
    )
}

data class Event(
    val id: Long = 0,
    val title: String,
    val date: LocalDate,
    val category: EventCategory = EventCategory.OTHER,
    val recurrence: Recurrence = Recurrence.NONE,
    val reminderOffsets: Set<Int> = emptySet(),
    val notes: String = "",
) {
    /**
     * The first occurrence on or after [from]. Non-recurring events return their own date, which
     * may be in the past (callers treat a negative day count as "passed").
     */
    fun occurrenceOnOrAfter(from: LocalDate): LocalDate {
        if (!date.isBefore(from)) return date
        return when (recurrence) {
            Recurrence.NONE -> date
            Recurrence.WEEKLY -> from.with(TemporalAdjusters.nextOrSame(date.dayOfWeek))
            Recurrence.MONTHLY -> {
                val day = date.dayOfMonth
                val thisMonth = YearMonth.from(from)
                val candidate = thisMonth.atDay(minOf(day, thisMonth.lengthOfMonth()))
                if (!candidate.isBefore(from)) {
                    candidate
                } else {
                    val next = thisMonth.plusMonths(1)
                    next.atDay(minOf(day, next.lengthOfMonth()))
                }
            }
            Recurrence.YEARLY -> {
                val monthDay = MonthDay.from(date) // Feb 29 falls back to Feb 28 in non-leap years
                val candidate = monthDay.atYear(from.year)
                if (!candidate.isBefore(from)) candidate else monthDay.atYear(from.year + 1)
            }
        }
    }

    fun daysRemaining(today: LocalDate): Long =
        ChronoUnit.DAYS.between(today, occurrenceOnOrAfter(today))

    fun toUpcoming(today: LocalDate): UpcomingEvent {
        val next = occurrenceOnOrAfter(today)
        return UpcomingEvent(this, next, ChronoUnit.DAYS.between(today, next))
    }

    /**
     * The next moment a reminder should fire strictly after [now], at [hour]:00 local time, or null
     * if there is none (no offsets chosen, or a one-off event whose reminders are all in the past).
     */
    fun nextReminderTrigger(now: LocalDateTime, hour: Int): LocalDateTime? {
        if (reminderOffsets.isEmpty()) return null
        var occurrence = occurrenceOnOrAfter(now.toLocalDate())
        repeat(3) {
            val best = reminderOffsets
                .map { occurrence.minusDays(it.toLong()).atTime(hour, 0) }
                .filter { it.isAfter(now) }
                .minOrNull()
            if (best != null) return best
            if (recurrence == Recurrence.NONE) return null
            occurrence = occurrenceOnOrAfter(occurrence.plusDays(1))
        }
        return null
    }
}

data class UpcomingEvent(
    val event: Event,
    val date: LocalDate,
    val daysRemaining: Long,
) {
    val passed: Boolean get() = daysRemaining < 0
}
