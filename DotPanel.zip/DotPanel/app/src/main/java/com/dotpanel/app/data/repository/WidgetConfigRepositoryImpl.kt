package com.dotpanel.app.data.repository

import com.dotpanel.app.data.toDomain
import com.dotpanel.app.data.toEntity
import com.dotpanel.app.database.WidgetConfigDao
import com.dotpanel.app.domain.model.WidgetConfig
import com.dotpanel.app.domain.repository.WidgetConfigRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WidgetConfigRepositoryImpl @Inject constructor(
    private val dao: WidgetConfigDao,
) : WidgetConfigRepository {
    override suspend fun get(appWidgetId: Int): WidgetConfig? = dao.get(appWidgetId)?.toDomain()
    override suspend fun save(config: WidgetConfig) = dao.upsert(config.toEntity())
    override suspend fun delete(appWidgetIds: List<Int>) = dao.delete(appWidgetIds)
}
