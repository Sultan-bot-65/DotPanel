package com.dotpanel.app.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.dotpanel.app.data.toEnumOrDefault
import com.dotpanel.app.domain.model.AppSettings
import com.dotpanel.app.domain.model.ThemeMode
import com.dotpanel.app.domain.repository.ReminderScheduler
import com.dotpanel.app.domain.repository.SettingsRepository
import dagger.Lazy
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dotpanel_settings")

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    // Lazy breaks the cycle SettingsRepository -> ReminderScheduler -> SettingsRepository.
    private val scheduler: Lazy<ReminderScheduler>,
) : SettingsRepository {

    private object Keys {
        val theme = stringPreferencesKey("theme_mode")
        val use24h = booleanPreferencesKey("use_24h")
        val activePreset = longPreferencesKey("active_preset")
        val eventHour = intPreferencesKey("event_reminder_hour")
        val goalEnabled = booleanPreferencesKey("goal_reminder_enabled")
        val goalHour = intPreferencesKey("goal_reminder_hour")
    }

    override val settings: Flow<AppSettings> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            val defaults = AppSettings()
            AppSettings(
                themeMode = prefs[Keys.theme]?.toEnumOrDefault(defaults.themeMode) ?: defaults.themeMode,
                use24HourClock = prefs[Keys.use24h] ?: defaults.use24HourClock,
                activePresetId = prefs[Keys.activePreset] ?: defaults.activePresetId,
                eventReminderHour = prefs[Keys.eventHour] ?: defaults.eventReminderHour,
                goalReminderEnabled = prefs[Keys.goalEnabled] ?: defaults.goalReminderEnabled,
                goalReminderHour = prefs[Keys.goalHour] ?: defaults.goalReminderHour,
            )
        }

    override suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.theme] = mode.name }
    }

    override suspend fun setUse24HourClock(value: Boolean) {
        context.dataStore.edit { it[Keys.use24h] = value }
    }

    override suspend fun setActivePresetId(id: Long) {
        context.dataStore.edit { it[Keys.activePreset] = id }
    }

    override suspend fun setEventReminderHour(hour: Int) {
        context.dataStore.edit { it[Keys.eventHour] = hour.coerceIn(0, 23) }
        scheduler.get().rescheduleAll()
    }

    override suspend fun setGoalReminderEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.goalEnabled] = enabled }
        scheduler.get().syncGoalReminder()
    }

    override suspend fun setGoalReminderHour(hour: Int) {
        context.dataStore.edit { it[Keys.goalHour] = hour.coerceIn(0, 23) }
        scheduler.get().syncGoalReminder()
    }
}
