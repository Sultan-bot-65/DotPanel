package com.dotpanel.app.feature.events

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dotpanel.app.core.util.daysShort
import com.dotpanel.app.core.util.formatDayMonth
import com.dotpanel.app.designsystem.DotCard
import com.dotpanel.app.designsystem.DotChip
import com.dotpanel.app.designsystem.DotIconButton
import com.dotpanel.app.designsystem.DotLabel
import com.dotpanel.app.designsystem.DotTextFit
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.designsystem.EmptyState
import com.dotpanel.app.designsystem.ScreenHeader
import com.dotpanel.app.domain.model.EventCategory
import com.dotpanel.app.domain.model.Recurrence
import com.dotpanel.app.domain.model.UpcomingEvent
import com.dotpanel.app.navigation.Routes

@Composable
fun EventsScreen(
    onOpenEvent: (Long) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: EventsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier.fillMaxSize().statusBarsPadding()) {
        ScreenHeader(
            title = "Events",
            subtitle = "Countdowns & reminders",
            actions = { DotIconButton(Icons.Outlined.Add, "Add event", { onOpenEvent(Routes.NEW_ID) }, filled = true) },
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { DotChip("All", state.filter == null, { viewModel.setFilter(null) }) }
            items(EventCategory.entries) { category ->
                DotChip(category.label, state.filter == category, { viewModel.setFilter(category) })
            }
        }
        Spacer(Modifier.height(12.dp))

        if (!state.loading && state.isEmpty) {
            EmptyState(
                message = if (state.filter == null) "No events yet." else "No ${state.filter!!.label.lowercase()} events.",
                hint = "Tap + to add a birthday, exam or trip",
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(state.upcoming, key = { "u${it.event.id}" }) { item ->
                    EventRow(item, onClick = { onOpenEvent(item.event.id) })
                }
                if (state.passed.isNotEmpty()) {
                    item(key = "passed-header") {
                        DotLabel("Passed", Modifier.padding(top = 12.dp, bottom = 2.dp))
                    }
                    items(state.passed, key = { "p${it.event.id}" }) { item ->
                        EventRow(item, onClick = { onOpenEvent(item.event.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun EventRow(item: UpcomingEvent, onClick: () -> Unit) {
    val colors = DotTheme.colors
    val event = item.event
    val dim = if (item.passed) colors.textSecondary else colors.textPrimary
    DotCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(76.dp), contentAlignment = Alignment.CenterStart) {
                Column {
                    DotTextFit(
                        text = if (item.daysRemaining == 0L) "NOW" else kotlin.math.abs(item.daysRemaining).toString(),
                        maxDotSize = 6.dp,
                        color = if (item.passed) colors.textSecondary else colors.accent,
                    )
                    Spacer(Modifier.height(6.dp))
                    DotLabel(
                        when {
                            item.daysRemaining == 0L -> "today"
                            item.passed -> "days ago"
                            item.daysRemaining == 1L -> "day"
                            else -> "days"
                        },
                    )
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    event.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = dim,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                DotLabel(
                    buildString {
                        append(item.date.formatDayMonth())
                        append("  ·  ").append(event.category.label)
                        if (event.recurrence != Recurrence.NONE) append("  ·  ").append(event.recurrence.label)
                    },
                    maxLines = 2,
                )
            }
            if (event.reminderOffsets.isNotEmpty()) {
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Outlined.Notifications,
                    contentDescription = "Reminder set",
                    tint = colors.textSecondary,
                    modifier = Modifier.padding(2.dp),
                )
            }
        }
    }
}
