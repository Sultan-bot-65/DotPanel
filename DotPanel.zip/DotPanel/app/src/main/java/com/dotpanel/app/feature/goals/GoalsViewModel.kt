package com.dotpanel.app.feature.goals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dotpanel.app.core.util.DateProvider
import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.model.GoalStats
import com.dotpanel.app.domain.repository.GoalRepository
import com.dotpanel.app.domain.usecase.GoalStatsCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GoalItem(val goal: Goal, val done: Boolean)

data class GoalsUiState(
    val loading: Boolean = true,
    val today: LocalDate = LocalDate.now(),
    val items: List<GoalItem> = emptyList(),
    val stats: GoalStats? = null,
)

@HiltViewModel
class GoalsViewModel @Inject constructor(
    private val goals: GoalRepository,
    private val dateProvider: DateProvider,
) : ViewModel() {

    val uiState: StateFlow<GoalsUiState> =
        combine(goals.observeGoals(), goals.observeCompletions(), dateProvider.todayFlow) { list, completions, today ->
            val todayEpoch = today.toEpochDay()
            val doneToday = completions.filter { it.epochDay == todayEpoch }.mapTo(HashSet()) { it.goalId }
            GoalsUiState(
                loading = false,
                today = today,
                items = list.map { GoalItem(it, it.id in doneToday) },
                stats = GoalStatsCalculator.calculate(list, completions, today),
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GoalsUiState())

    fun addGoal(title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch { goals.addGoal(clean) }
    }

    fun toggle(item: GoalItem) {
        viewModelScope.launch {
            goals.setCompleted(item.goal.id, dateProvider.today().toEpochDay(), !item.done)
        }
    }

    /** Archives the goal; its completion history stays in the database and in backups. */
    fun remove(goalId: Long) {
        viewModelScope.launch { goals.removeGoal(goalId) }
    }
}
