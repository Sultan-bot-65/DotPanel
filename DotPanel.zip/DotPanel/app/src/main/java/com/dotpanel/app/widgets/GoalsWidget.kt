package com.dotpanel.app.widgets

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.Text
import com.dotpanel.app.domain.model.Goal
import com.dotpanel.app.domain.usecase.GoalStatsCalculator
import com.dotpanel.app.navigation.Routes

private data class GoalRowData(val goal: Goal, val done: Boolean)

private data class GoalsSnapshot(val rows: List<GoalRowData>, val total: Int, val completed: Int, val streak: Int)

/** Today's goals. Tapping a goal's dot checks it off (or back on) without opening the app. */
class GoalsWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val entry = context.widgetEntryPoint()
        val appWidgetId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val hideCompleted = entry.widgetConfigs().get(appWidgetId)?.hideCompleted ?: false
        val today = entry.dateProvider().today()

        val goals = entry.goals().getGoals()
        val completions = entry.goals().getCompletions()
        val doneToday = completions.filter { it.epochDay == today.toEpochDay() }.mapTo(HashSet()) { it.goalId }
        val stats = GoalStatsCalculator.calculate(goals, completions, today)
        val allRows = goals.map { GoalRowData(it, it.id in doneToday) }
        val snapshot = GoalsSnapshot(
            rows = if (hideCompleted) allRows.filter { !it.done } else allRows,
            total = stats.total,
            completed = stats.completedToday,
            streak = stats.currentStreak,
        )

        provideContent {
            val size = LocalSize.current
            WidgetFrame(onClick = openRoute(Routes.GOALS)) {
                GoalsContent(snapshot, size.width - 24.dp, size.height - 24.dp)
            }
        }
    }
}

@Composable
private fun GoalsContent(snapshot: GoalsSnapshot, innerWidth: Dp, innerHeight: Dp) {
    Column(modifier = GlanceModifier.fillMaxSize()) {
        Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Dot(WidgetColors.accent)
            Spacer(GlanceModifier.width(6.dp))
            Text("GOALS", style = widgetText(WidgetColors.textSecondary, 10.sp), maxLines = 1)
            Spacer(GlanceModifier.defaultWeight())
            Text(
                "${snapshot.completed}/${snapshot.total}",
                style = widgetText(size = 12.sp, bold = true),
                maxLines = 1,
            )
        }
        Spacer(GlanceModifier.height(6.dp))
        DotProgressImage(
            fraction = if (snapshot.total == 0) 0f else snapshot.completed.toFloat() / snapshot.total,
            width = innerWidth,
        )
        Spacer(GlanceModifier.height(6.dp))

        if (snapshot.total == 0) {
            Text("No goals yet", style = widgetText(size = 13.sp, bold = true))
            Text("Tap to add one", style = widgetText(WidgetColors.textSecondary, 11.sp))
            return@Column
        }
        if (snapshot.rows.isEmpty()) {
            Text("ALL DONE", style = widgetText(size = 13.sp, bold = true))
            if (snapshot.streak > 0) {
                Text("${snapshot.streak} day streak", style = widgetText(WidgetColors.textSecondary, 11.sp))
            }
            return@Column
        }

        // Header + progress take about 44dp; each goal row is 30dp. Reserve one line for "+N more".
        val capacity = ((innerHeight.value - 44f) / ROW_HEIGHT.value).toInt().coerceAtLeast(1)
        val visible = if (snapshot.rows.size > capacity) (capacity - 1).coerceAtLeast(1) else snapshot.rows.size
        snapshot.rows.take(visible).forEach { GoalRow(it) }
        val hidden = snapshot.rows.size - visible
        if (hidden > 0) {
            Text("+$hidden more", style = widgetText(WidgetColors.textSecondary, 11.sp), maxLines = 1)
        }
    }
}

private val ROW_HEIGHT = 30.dp

@Composable
private fun GoalRow(row: GoalRowData) {
    val toggle = actionRunCallback<ToggleGoalAction>(
        actionParametersOf(
            ToggleGoalAction.GoalIdKey to row.goal.id,
            ToggleGoalAction.DoneKey to row.done,
        ),
    )
    Row(
        modifier = GlanceModifier.fillMaxWidth().height(ROW_HEIGHT).clickable(toggle),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // The dot is the checkbox: filled red when done, an outline ring otherwise.
        Box(
            modifier = GlanceModifier.size(16.dp).background(if (row.done) WidgetColors.accent else WidgetColors.textSecondary)
                .cornerRadius(8.dp),
            contentAlignment = Alignment.Center,
        ) {
            if (!row.done) {
                Box(
                    modifier = GlanceModifier.size(13.dp).background(WidgetColors.background).cornerRadius(6.5.dp),
                    content = {},
                )
            }
        }
        Spacer(GlanceModifier.width(8.dp))
        Text(
            row.goal.title,
            style = widgetText(if (row.done) WidgetColors.textSecondary else WidgetColors.textPrimary, 13.sp),
            maxLines = 1,
        )
    }
}

/** Runs in the background when a goal dot is tapped: writes to Room, then redraws the widgets. */
class ToggleGoalAction : ActionCallback {

    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val goalId = parameters[GoalIdKey] ?: return
        val wasDone = parameters[DoneKey] ?: return
        val entry = context.widgetEntryPoint()
        entry.goals().setCompleted(goalId, entry.dateProvider().today().toEpochDay(), !wasDone)
        // Redraw straight away instead of waiting for the debounced refresh, so the tap feels instant.
        GoalsWidget().updateAll(context)
        SummaryWidget().updateAll(context)
    }

    companion object {
        val GoalIdKey = ActionParameters.Key<Long>("goalId")
        val DoneKey = ActionParameters.Key<Boolean>("done")
    }
}

class GoalsWidgetReceiver : DotPanelWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = GoalsWidget()
}
