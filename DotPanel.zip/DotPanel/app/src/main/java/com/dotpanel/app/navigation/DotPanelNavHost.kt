package com.dotpanel.app.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dotpanel.app.designsystem.BottomBarItem
import com.dotpanel.app.designsystem.DotBottomBar
import com.dotpanel.app.designsystem.DotTheme
import com.dotpanel.app.feature.dashboard.DashboardEditScreen
import com.dotpanel.app.feature.dashboard.DashboardScreen
import com.dotpanel.app.feature.events.EventEditorScreen
import com.dotpanel.app.feature.events.EventsScreen
import com.dotpanel.app.feature.goals.GoalsScreen
import com.dotpanel.app.feature.notes.NoteEditorScreen
import com.dotpanel.app.feature.notes.NotesScreen
import com.dotpanel.app.feature.settings.SettingsScreen

private val bottomItems = listOf(
    BottomBarItem(Routes.DASHBOARD, "Home", Icons.Outlined.Home),
    BottomBarItem(Routes.EVENTS, "Events", Icons.Outlined.DateRange),
    BottomBarItem(Routes.NOTES, "Notes", Icons.Outlined.Create),
    BottomBarItem(Routes.GOALS, "Goals", Icons.Outlined.CheckCircle),
    BottomBarItem(Routes.SETTINGS, "Settings", Icons.Outlined.Settings),
)

@Composable
fun DotPanelNavHost(pendingRoute: String?, onRouteHandled: () -> Unit) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val currentRoute = entry?.destination?.route

    // Widget / notification taps arrive as a route string; ignore anything we don't recognise.
    LaunchedEffect(pendingRoute) {
        if (pendingRoute != null) {
            runCatching { nav.navigateToRoute(pendingRoute) }
            onRouteHandled()
        }
    }

    Scaffold(
        containerColor = DotTheme.colors.background,
        // Screens apply their own status/navigation-bar insets (see each screen's root modifier).
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (currentRoute != null && currentRoute in Routes.topLevel) {
                DotBottomBar(bottomItems, currentRoute, onSelect = { nav.navigateTopLevel(it) })
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.DASHBOARD,
            modifier = Modifier.padding(padding),
            enterTransition = { fadeIn(tween(200)) },
            exitTransition = { fadeOut(tween(120)) },
            popEnterTransition = { fadeIn(tween(200)) },
            popExitTransition = { fadeOut(tween(120)) },
        ) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    onNavigate = { route -> runCatching { nav.navigateToRoute(route) } },
                    onEditLayout = { nav.navigate(Routes.DASHBOARD_EDIT) },
                )
            }
            composable(Routes.DASHBOARD_EDIT) {
                DashboardEditScreen(onBack = { nav.popBackStack() })
            }
            composable(Routes.EVENTS) {
                EventsScreen(onOpenEvent = { id -> nav.navigate(Routes.event(id)) })
            }
            composable(
                Routes.EVENT_EDITOR,
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) {
                EventEditorScreen(onClose = { nav.popBackStack() })
            }
            composable(Routes.NOTES) {
                NotesScreen(onOpenNote = { id -> nav.navigate(Routes.note(id)) })
            }
            composable(
                Routes.NOTE_EDITOR,
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) {
                NoteEditorScreen(onClose = { nav.popBackStack() })
            }
            composable(Routes.GOALS) { GoalsScreen() }
            composable(Routes.SETTINGS) { SettingsScreen() }
        }
    }
}

private fun NavHostController.navigateTopLevel(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

/** Top-level routes switch tabs; anything else (event/5, note/-1) is pushed on top. */
private fun NavHostController.navigateToRoute(route: String) {
    if (route in Routes.topLevel) navigateTopLevel(route) else navigate(route)
}
