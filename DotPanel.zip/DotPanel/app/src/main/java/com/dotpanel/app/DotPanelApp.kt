package com.dotpanel.app

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.dotpanel.app.core.di.ApplicationScope
import com.dotpanel.app.core.notifications.NotificationHelper
import com.dotpanel.app.domain.repository.DashboardRepository
import com.dotpanel.app.domain.repository.ReminderScheduler
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@HiltAndroidApp
class DotPanelApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var dashboard: DashboardRepository
    @Inject lateinit var reminders: ReminderScheduler

    /** Injected only so its init block creates the notification channels at startup. */
    @Inject lateinit var notifications: NotificationHelper

    @Inject @field:ApplicationScope lateinit var appScope: CoroutineScope

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setWorkerFactory(workerFactory).build()

    override fun onCreate() {
        super.onCreate()
        appScope.launch {
            dashboard.ensureDefaults()
            // Re-arms every pending reminder; cheap, and repairs anything the system dropped.
            reminders.rescheduleAll()
        }
    }
}
