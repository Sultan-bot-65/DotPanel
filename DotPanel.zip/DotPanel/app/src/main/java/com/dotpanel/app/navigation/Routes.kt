package com.dotpanel.app.navigation

object Routes {
    const val DASHBOARD = "dashboard"
    const val DASHBOARD_EDIT = "dashboard/edit"
    const val EVENTS = "events"
    const val EVENT_EDITOR = "event/{id}"
    const val NOTES = "notes"
    const val NOTE_EDITOR = "note/{id}"
    const val GOALS = "goals"
    const val SETTINGS = "settings"

    const val NEW_ID = -1L

    fun event(id: Long) = "event/$id"
    fun note(id: Long) = "note/$id"

    val topLevel = listOf(DASHBOARD, EVENTS, NOTES, GOALS, SETTINGS)
}
