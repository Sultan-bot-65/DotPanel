package com.dotpanel.app.designsystem

import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput

/**
 * Long-press-and-drag reordering for a [LazyListState]-backed list.
 *
 * Rules for the list: no `contentPadding` (apply padding on the list's modifier instead, so item
 * offsets match pointer coordinates) and stable `key`s on every item.
 *
 * [onMove] is invoked while dragging with (fromIndex, toIndex) so the caller can swap the items in
 * its own state; [onDragEnd] fires once when the finger lifts so the order can be persisted.
 */
class DragDropState internal constructor(
    private val listState: LazyListState,
    private val onMove: (Int, Int) -> Unit,
    private val onDragEnd: () -> Unit,
) {
    var draggingItemIndex by mutableStateOf<Int?>(null)
        private set

    private var draggedDistance by mutableFloatStateOf(0f)
    private var draggingItemInitialOffset by mutableIntStateOf(0)

    private val draggingItemLayoutInfo
        get() = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == draggingItemIndex }

    /** Vertical translation to apply to the dragged item so it follows the finger. */
    val draggingItemOffset: Float
        get() = draggingItemLayoutInfo?.let { item ->
            draggingItemInitialOffset + draggedDistance - item.offset
        } ?: 0f

    internal fun onDragStart(offset: Offset) {
        listState.layoutInfo.visibleItemsInfo
            .firstOrNull { offset.y.toInt() in it.offset until (it.offset + it.size) }
            ?.let {
                draggingItemIndex = it.index
                draggingItemInitialOffset = it.offset
            }
    }

    internal fun onDrag(delta: Offset) {
        draggedDistance += delta.y
        val dragging = draggingItemLayoutInfo ?: return
        val middle = dragging.offset + draggingItemOffset + dragging.size / 2f
        val target = listState.layoutInfo.visibleItemsInfo.firstOrNull { item ->
            item.index != dragging.index && middle.toInt() in item.offset until (item.offset + item.size)
        }
        if (target != null) {
            onMove(dragging.index, target.index)
            draggingItemIndex = target.index
        }
    }

    internal fun onDragFinished() {
        val wasDragging = draggingItemIndex != null
        draggingItemIndex = null
        draggedDistance = 0f
        draggingItemInitialOffset = 0
        if (wasDragging) onDragEnd()
    }
}

@Composable
fun rememberDragDropState(
    listState: LazyListState,
    onMove: (Int, Int) -> Unit,
    onDragEnd: () -> Unit,
): DragDropState {
    val move by rememberUpdatedState(onMove)
    val end by rememberUpdatedState(onDragEnd)
    return remember(listState) { DragDropState(listState, { a, b -> move(a, b) }, { end() }) }
}

/** Attach to the lazy list itself: long-press an item, then drag it up or down. */
fun Modifier.dragContainer(state: DragDropState): Modifier = pointerInput(state) {
    detectDragGesturesAfterLongPress(
        onDragStart = { state.onDragStart(it) },
        onDrag = { change, amount ->
            change.consume()
            state.onDrag(amount)
        },
        onDragEnd = { state.onDragFinished() },
        onDragCancel = { state.onDragFinished() },
    )
}
