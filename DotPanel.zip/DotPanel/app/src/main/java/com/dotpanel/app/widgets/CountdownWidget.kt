package com.dotpanel.app.widgets

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.width
import androidx.glance.text.Text
import com.dotpanel.app.core.util.formatShort
import com.dotpanel.app.domain.model.UpcomingEvent
import com.dotpanel.app.domain.model.WidgetConfig
import com.dotpanel.app.navigation.Routes
import kotlin.math.abs

/** Days remaining until one event: the one chosen in the widget settings, or else the next upcoming. */
class CountdownWidget : GlanceAppWidget() {

    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val entry = context.widgetEntryPoint()
        val appWidgetId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val config = entry.widgetConfigs().get(appWidgetId)
        val today = entry.dateProvider().today()
        val target = CountdownSelection.choose(entry.events().getEvents().map { it.toUpcoming(today) }, config)

        provideContent {
            val size = LocalSize.current
            WidgetFrame(onClick = openRoute(Routes.event(target?.event?.id ?: Routes.NEW_ID))) {
                if (target == null) EmptyContent() else CountdownContent(target, size.width - 24.dp, size.height - 24.dp)
            }
        }
    }
}

/** Pure selection rule, separated so it can be unit-tested without Android. */
internal object CountdownSelection {
    fun choose(all: List<UpcomingEvent>, config: WidgetConfig?): UpcomingEvent? {
        val chosen = config?.targetId?.takeIf { it != WidgetConfig.NO_TARGET }
            ?.let { id -> all.firstOrNull { it.event.id == id } }
        return chosen ?: all.filter { !it.passed }.minByOrNull { it.daysRemaining }
    }
}

@Composable
private fun EmptyContent() {
    Column(modifier = GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Text("NO EVENT", style = widgetText(size = 14.sp, bold = true))
        Spacer(GlanceModifier.height(4.dp))
        Text("Tap to add one", style = widgetText(WidgetColors.textSecondary, 11.sp))
    }
}

@Composable
private fun CountdownContent(
    event: UpcomingEvent,
    innerWidth: Dp,
    innerHeight: Dp,
) {
    val days = event.daysRemaining
    val roomy = innerHeight >= 120.dp
    Column(modifier = GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Dot(WidgetColors.accent)
            Spacer(GlanceModifier.width(6.dp))
            Text(event.event.category.label.uppercase(), style = widgetText(WidgetColors.textSecondary, 10.sp), maxLines = 1)
        }
        Spacer(GlanceModifier.height(6.dp))
        DotTextImage(
            text = abs(days).toString(),
            maxWidth = innerWidth,
            maxHeight = if (roomy) 56.dp else 36.dp,
            maxDot = 8.dp,
            description = "${abs(days)} days",
        )
        Spacer(GlanceModifier.height(4.dp))
        Text(unitLabel(days), style = widgetText(WidgetColors.textSecondary, 10.sp), maxLines = 1)
        Spacer(GlanceModifier.height(6.dp))
        Text(event.event.title, style = widgetText(size = 14.sp, bold = true), maxLines = if (roomy) 2 else 1)
        if (roomy) {
            Text(event.date.formatShort(), style = widgetText(WidgetColors.textSecondary, 11.sp), maxLines = 1)
        }
    }
}

internal fun unitLabel(days: Long): String = when {
    days == 0L -> "TODAY"
    days == 1L -> "DAY LEFT"
    days > 1 -> "DAYS LEFT"
    days == -1L -> "DAY AGO"
    else -> "DAYS AGO"
}

class CountdownWidgetReceiver : DotPanelWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = CountdownWidget()
}
