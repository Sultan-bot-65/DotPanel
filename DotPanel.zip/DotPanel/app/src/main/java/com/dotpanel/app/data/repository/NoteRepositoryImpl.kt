package com.dotpanel.app.data.repository

import com.dotpanel.app.data.toDomain
import com.dotpanel.app.data.toEntity
import com.dotpanel.app.database.NoteDao
import com.dotpanel.app.domain.model.Note
import com.dotpanel.app.domain.repository.NoteRepository
import com.dotpanel.app.domain.repository.WidgetRefresher
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Singleton
class NoteRepositoryImpl @Inject constructor(
    private val dao: NoteDao,
    private val widgets: WidgetRefresher,
) : NoteRepository {

    override fun observeNotes(): Flow<List<Note>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun getNote(id: Long): Note? = dao.get(id)?.toDomain()

    override suspend fun getNotes(): List<Note> = dao.getAll().map { it.toDomain() }

    override suspend fun upsert(note: Note): Long {
        val now = System.currentTimeMillis()
        val entity = note.copy(
            createdAt = if (note.createdAt == 0L) now else note.createdAt,
            updatedAt = now,
        ).toEntity()
        val result = dao.upsert(entity)
        widgets.requestRefresh()
        return if (result == -1L) note.id else result
    }

    override suspend fun delete(id: Long) {
        dao.delete(id)
        widgets.requestRefresh()
    }
}
