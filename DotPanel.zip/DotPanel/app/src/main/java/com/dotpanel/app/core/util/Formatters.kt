package com.dotpanel.app.core.util

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private val shortDate = DateTimeFormatter.ofPattern("d MMM yyyy")
private val dayMonth = DateTimeFormatter.ofPattern("EEE, d MMM")

fun LocalDate.formatShort(): String = format(shortDate)
fun LocalDate.formatDayMonth(): String = format(dayMonth)

fun formatHour(hour: Int, use24Hour: Boolean): String {
    val time = LocalTime.of(hour.coerceIn(0, 23), 0)
    return time.format(DateTimeFormatter.ofPattern(if (use24Hour) "HH:mm" else "h:mm a"))
}

/** "Today", "Tomorrow", "12 days", "3 days ago". */
fun daysLabel(days: Long): String = when {
    days == 0L -> "Today"
    days == 1L -> "Tomorrow"
    days == -1L -> "Yesterday"
    days > 1 -> "$days days"
    else -> "${-days} days ago"
}

/** Compact form for dot-matrix display: "12D", "NOW". */
fun daysShort(days: Long): String = when {
    days == 0L -> "NOW"
    days > 0 -> "${days}D"
    else -> "${-days}D AGO"
}
