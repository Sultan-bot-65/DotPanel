-keepattributes *Annotation*, InnerClasses, Signature
# Backup JSON uses the Room entities directly as @Serializable DTOs.
-keep class com.dotpanel.app.database.** { *; }
-keepclassmembers class com.dotpanel.app.database.** { *; }
-keep,includedescriptorclasses class com.dotpanel.app.**$$serializer { *; }
-keepclassmembers class com.dotpanel.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.dotpanel.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
