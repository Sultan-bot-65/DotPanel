# DotPanel — Your Life. Your Dashboard.

A local-first, offline personal dashboard for Android with a Nothing OS-inspired look:
AMOLED black, monochrome, dot-matrix type, one red accent.

## Features
- **Dashboard engine** – add/remove/hide cards, drag-and-drop reorder, S/M/L sizes, multiple saved presets.
  Cards: Clock & Date, Battery, Upcoming Events, Daily Goals, Quick Notes, Custom Text.
- **Countdowns & events** – Birthday / Exam / Travel / Anniversary / Work / Other, recurrence
  (weekly, monthly, yearly), days remaining, per-event reminders.
- **Quick notes** – auto-save, pin, search, colour labels, dashboard previews.
- **Daily goals** – completion %, streaks, permanent per-day history.
- **Glance widgets** – Clock, Countdown, Daily Goals, Quick Notes, Dashboard Summary; each with its own
  configuration screen, Room-synced data, tap actions and refresh on date/time/zone change.
- **Backup** – JSON export/import via the system file picker with validation before anything is written.
- **Privacy** – no account, no network code, no analytics, `allowBackup=false`.
  The only permission is `POST_NOTIFICATIONS`.

## Architecture
Feature-based Clean Architecture, MVVM, single `:app` module, packages under `com.dotpanel.app`:

| Package | Role |
|---|---|
| `domain` | Pure Kotlin models, repository interfaces, use cases (no Android types) |
| `data` | Repository implementations, mappers, DataStore settings, JSON backup codec |
| `database` | Room entities, DAOs, database, migration registry (no destructive fallback) |
| `core` | DI (Hilt), notifications + WorkManager scheduling, utilities |
| `designsystem` | Theme, dot-matrix renderer, shared components, drag-and-drop |
| `feature/*` | Compose screens + ViewModels (dashboard, events, notes, goals, settings) |
| `widgets` | Glance widgets, config activity, refresher, Hilt entry point |

Data flow: Room DAO `Flow` → repository (domain models) → ViewModel `StateFlow` → Compose.
Widgets read the same repositories through a Hilt `EntryPoint`, so app and widgets never diverge.

Reminders use WorkManager only. A reminder that fires "around 9:00" does not need an exact alarm, so the
app avoids `SCHEDULE_EXACT_ALARM`/`USE_EXACT_ALARM`. All reminders are rescheduled on app start,
settings change and backup import.

## Build
Requirements: JDK 17, Android SDK 35 (Android Studio Ladybug or newer).

```bash
./gradlew assembleDebug            # debug APK -> app/build/outputs/apk/debug
./gradlew testDebugUnitTest        # JUnit + MockK unit tests
./gradlew lintDebug                # static checks
```

Release: create `keystore.properties` in the project root (git-ignored) with `storeFile`,
`storePassword`, `keyAlias`, `keyPassword`, then `./gradlew bundleRelease`.
Room schemas export to `app/schemas/`; commit them and add a `Migration` in
`DotPanelMigrations` whenever `DotPanelDatabase.VERSION` changes.

Versions are pinned in `gradle/libs.versions.toml` (AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01,
Room 2.6.1, Hilt 2.52, Glance 1.1.1, WorkManager 2.10.0).

## Notes

License: MIT (see `LICENSE`).
